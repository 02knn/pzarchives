








require "ISUI/ISEquippedItem"
require "Vehicles/TimedActions/ISOpenVehicleDoor"
require "Viewpoint_InvScreen"
require "Viewpoint_InvInput"
require "Viewpoint_InvPad"



ViewpointInventory = ViewpointInventory or {}
ViewpointInventory.wrapped = ViewpointInventory.wrapped or {}


local PLAYER = 0

local SIDEBAR_TABS = { INVENTORY = "character", HEALTH = "health" }

local PANEL_TABS = {
    { KeybindId.TOGGLE_INFO_PANEL, "info" },
    { KeybindId.TOGGLE_SKILL_PANEL, "skills" },
    { KeybindId.TOGGLE_HEALTH_PANEL, "health" },
    { KeybindId.TOGGLE_CLOTHING_PROTECTION_PANEL, "protection" },
}


local windowsUp = false


local nextFocus



local function showWindows()
    local loot, inventory = getPlayerLoot(PLAYER), getPlayerInventory(PLAYER)
    if not (loot and inventory) then return false end
    for _, page in ipairs({ loot, inventory }) do
        page:setVisible(true)
        if page.isCollapsed then
            if isClient() and not page.onCharacter then page.inventoryPane.inventory:requestSync() end
            page.isCollapsed = false
            page:clearMaxDrawHeight()
        end
        page.collapseCounter = 0
    end
    return true
end

local function hideWindows()
    for _, page in ipairs({ getPlayerLoot(PLAYER), getPlayerInventory(PLAYER) }) do
        if page then page:setVisible(false) end
    end
end



local function closeSidebarWindows()
    for _, key in ipairs({ "HandcraftWindow", "BuildWindow" }) do
        local window = ISEntityUI.GetWindowInstance(PLAYER, key)
        if window then window:close() end
    end
    local player = getSpecificPlayer(PLAYER)
    local search = player and ISSearchWindow.players[player]
    if search and search:getIsVisible() then ISSearchWindow.toggleWindow(player) end
    local zones = getPlayerZoneUI(PLAYER)
    if zones and zones:getIsVisible() then ISDesignationZonePanel.toggleZoneUI(PLAYER) end
    if ISDebugMenu.instance then ISDebugMenu.instance:close() end
end



function ViewpointInventory.open(how)
    local focus = nextFocus
    nextFocus = nil
    if how == "screen" then
        closeSidebarWindows()
        return ViewpointInvScreen.show(focus)
    end
    if how == "back" then return ViewpointInvScreen.show(nil, true) end
    local shown = showWindows()
    if how == "windows" then windowsUp = windowsUp or shown end
    return shown
end

function ViewpointInventory.close()
    nextFocus = nil
    ViewpointInvScreen.hide()
    if windowsUp then hideWindows() end
    windowsUp = false
end


function ViewpointInventory.release()
    nextFocus = nil
    ViewpointInvScreen.hide()
    windowsUp = false
end


function ViewpointInventory.away()
    ViewpointInvScreen.hide(true)
end


function ViewpointInventory.up()
    if ViewpointInvScreen.isUp() then return true end
    local inventory = getPlayerInventory(PLAYER)
    return windowsUp and inventory ~= nil and inventory:getIsVisible()
end


function ViewpointInventory.focus(container)
    ViewpointInvScreen.focusOn(container)
end


function ViewpointInventory.tab(id)
    if ViewpointInvScreen.isUp() then ViewpointInvScreen.instance:selectTab(id) end
end


local sidebarClick = ISEquippedItem.onOptionMouseDown

function ISEquippedItem:onOptionMouseDown(button, x, y)
    local tab = SIDEBAR_TABS[button.internal]
    local loot = Viewpoint and Viewpoint.Loot
    if tab and loot and self.chr:getPlayerNum() == PLAYER and loot.openScreen(tab) then return end
    return sidebarClick(self, button, x, y)
end


local data = getPlayerData(PLAYER)
if data and data.equipped then
    for _, button in ipairs({ data.equipped.invBtn, data.equipped.healthBtn }) do
        if button.onclick == sidebarClick then button.onclick = ISEquippedItem.onOptionMouseDown end
    end
end





local function openTrunk(action)
    local part, vehicle, chr = action.part, action.vehicle, action.character
    if isServer() or not (part and vehicle) or chr:getPlayerNum() ~= PLAYER or chr:getVehicle() then return false end
    if part:getId() ~= "TrunkDoor" and part:getId() ~= "DoorRear" then return false end
    local bed = vehicle:getPartById("TruckBed")
    local container = bed and bed:getItemContainer()
    if not container or not vehicle:canAccessContainer(bed:getIndex(), chr) then return false end
    local loot = Viewpoint and Viewpoint.Loot
    if not (loot and loot.openScreen(nil)) then return false end
    nextFocus = container
    local window = getPlayerLoot(PLAYER)
    if window then window:setForceSelectedContainer(container, 100) end
    return true
end


local wrapped = ViewpointInventory.wrapped
wrapped.trunk = wrapped.trunk or ISOpenVehicleDoor.selectContainerInLootWindow

function ISOpenVehicleDoor:selectContainerInLootWindow()
    if not openTrunk(self) then return wrapped.trunk(self) end
end




local function panelKey(key)
    if getGameSpeed() == 0 then return false end
    local tab
    for _, panel in ipairs(PANEL_TABS) do
        if getCore():isKey(panel[1], key) then tab = panel[2] end
    end
    if not tab then return false end
    local screen = ViewpointInvScreen.instance
    if ViewpointInvScreen.isUp() and screen.tabs.active == tab then
        ViewpointInventory.close()
        return true
    end
    local loot = Viewpoint and Viewpoint.Loot
    return loot ~= nil and loot.openScreen(tab)
end





local function wrapPanelKeys()
    local show = xpUpdate and xpUpdate.displayCharacterInfo
    local wrapped = ViewpointInventory.wrapped
    if not show or show == wrapped.panelKeys then return end
    wrapped.panelKeys = function(key)
        if not panelKey(key) then return show(key) end
    end
    xpUpdate.displayCharacterInfo = wrapped.panelKeys
    Events.OnKeyPressed.Remove(show)
    Events.OnKeyPressed.Add(wrapped.panelKeys)
end

wrapPanelKeys()
Events.OnGameStart.Add(wrapPanelKeys)
