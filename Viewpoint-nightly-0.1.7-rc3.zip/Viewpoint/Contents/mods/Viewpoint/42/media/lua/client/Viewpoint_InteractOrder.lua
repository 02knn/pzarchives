





ViewpointInteractOrder = {}
local O = ViewpointInteractOrder




local USUAL = { "onDrink", "onTakeWater", "onWashYourself", "onWashClothing", "onSleep", "onRest",
                "onClimbThroughWindow", "onClimbOverFence", "onClimbSheetRope", "onToggleClothingWasher",
                "onToggleClothingDryer", "onToggleComboWasherDryer", "activateRadio", "onLockDoor", "onUnLockDoor" }

local SELDOM = { "onFluidInfo", "onFluidEmpty", "addFluidDebug", "onSmashWindow", "onPutPadlock", "onRemovePadlock",
                 "onPutDigitalPadlock", "onRemoveDigitalPadlock", "onBarricade", "onUnbarricade", "onUnbarricadeMetal",
                 "onUnbarricadeMetalBar", "onTakeGenerator", "onRemovePlant", "onCheckStats", "onDestroy" }

local UNRANKED, LAST = 1000, 2000





function O.primary()
    local set = {}
    local W = ISWorldObjectContextMenu
    local A = AnimalContextMenu or {}
    local F = ISFarmingMenu or {}
    for _, f in ipairs({ W.onOpenCloseWindow, W.onOpenCloseDoor, W.onOpenCloseCurtain, W.onToggleLight,
                         W.onActivateGenerator, W.onToggleStove, A.onMilkAnimal, A.onShearAnimal, A.onPetAnimal,
                         W.onChopTree, F.onHarvest, F.onPlow }) do
        if f then set[f] = true end
    end
    return set
end


function O.ranks()
    local W = ISWorldObjectContextMenu
    local rank = {}
    for i, name in ipairs(USUAL) do
        if W[name] then rank[W[name]] = i end
    end
    for _, name in ipairs(SELDOM) do
        if W[name] then rank[W[name]] = LAST end
    end
    return rank
end

local function place(a)
    if a.first then return 0 end
    return a.rank or UNRANKED
end


function O.sort(list)
    local ordered, at = {}, {}
    for i, a in ipairs(list) do
        ordered[i], at[a] = a, i
    end
    table.sort(ordered, function(x, y)
        local px, py = place(x), place(y)
        if px ~= py then return px < py end
        return at[x] < at[y]
    end)
    return ordered
end
