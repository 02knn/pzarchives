



require "Viewpoint_InvStyle"
require "Viewpoint_InvData"

ViewpointInvHands = {}
local Hd = ViewpointInvHands
Hd.__index = Hd
local S = ViewpointInvStyle
local D = ViewpointInvData

local TITLE = "Hands"

function Hd.new()
    return setmetatable({ hits = {}, x = 0, y = 0, w = 0, h = 0 }, Hd)
end


function Hd.height(m)
    return m.title + m.pad * 2 + math.floor(m.unit * 1.3)
end

function Hd:layout(x, y, w, m)
    self.x, self.y, self.w, self.m = x, y, w, m
    self.size = math.floor(m.unit * 1.3)
    self.h = Hd.height(m)
end


local function partsOf(item)
    if not instanceof(item, "HandWeapon") then return nil end
    local list = item:getAllWeaponParts()
    if list:isEmpty() then return nil end
    return list
end

local function hit(self, x, y, w, h, target)
    table.insert(self.hits, { x = x, y = y, w = w, h = h, target = target })
end


function Hd:partsRow(ui, view, list, x, y, right)
    local m, size = self.m, self.size
    local p = math.max(20, size - m.font - m.pad * 3)
    local py = y + size - m.pad - p
    for i = 0, list:size() - 1 do
        local part = list:get(i)
        if x + p > right then return end
        local over = view.hover and view.hover.kind == "attachment" and view.hover.item == part
        S.slotBox(ui, x, py, p, p, over)
        local icon = math.floor(p * 0.7)
        ui.javaObject:DrawItemIcon(part, x + math.floor((p - icon) / 2), py + math.floor((p - icon) / 2), 1.0, icon, icon)
        hit(self, x, py, p, p, { kind = "attachment", item = part })
        x = x + p + m.gap
    end
end



function Hd:hand(ui, view, x, y, w, item, primary)
    local m, size = self.m, self.size
    local over = view.hover and view.hover.kind == "hand" and view.hover.primary == primary
    local condition = item and S.condition(D.condition(item), item:isBroken())
    S.slotBox(ui, x, y, w, size, over, (view.drag and over) and S.drop or nil, false, not item, condition)
    hit(self, x, y, w, size, { kind = "hand", primary = primary, item = item })
    local label = getText(primary and "IGUI_PrimaryTooltip" or "IGUI_SecondaryTooltip")
    if not item then
        S.textCentre(ui, label, x + math.floor(w / 2), y + math.floor((size - m.font) / 2), S.dim)
        return
    end
    local icon = math.floor(size * 0.72)
    ui.javaObject:DrawItemIcon(item, x + math.floor((size - icon) / 2), y + math.floor((size - icon) / 2), 1.0, icon, icon)
    local tx = x + size + m.pad
    local room = x + w - m.pad - tx
    S.text(ui, S.fit(item:getDisplayName(), room), tx, y + m.pad, S.bright)
    local list = partsOf(item)
    if list then
        self:partsRow(ui, view, list, tx, y, x + w - m.pad)
    else
        S.text(ui, S.fit(label, room), tx, y + m.pad + m.font, S.dim)
    end
end

function Hd:render(ui, view)
    local m = self.m
    self.hits = { { x = self.x, y = self.y, w = self.w, h = self.h, target = { kind = "hands" } } }
    S.window(ui, m, self.x, self.y, self.w, self.h, TITLE, true)
    local primary, secondary = view.player:getPrimaryHandItem(), view.player:getSecondaryHandItem()
    local y = self.y + m.title + m.pad
    if primary and primary == secondary then
        self:hand(ui, view, self.x + m.pad, y, self.w - m.pad * 2, primary, true)
        return
    end
    local w = math.floor((self.w - m.pad * 3) / 2)
    self:hand(ui, view, self.x + m.pad, y, w, primary, true)
    self:hand(ui, view, self.x + m.pad * 2 + w, y, w, secondary, false)
end

function Hd:hit(mx, my)
    for i = #self.hits, 1, -1 do
        local h = self.hits[i]
        if mx >= h.x and mx < h.x + h.w and my >= h.y and my < h.y + h.h then return h.target end
    end
    return nil
end
