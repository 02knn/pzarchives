




require "ISUI/ISToolTipInv"
require "Viewpoint_InvStyle"
require "Viewpoint_InvData"

ViewpointInvDetails = {}
local Dt = ViewpointInvDetails
Dt.__index = Dt
local S = ViewpointInvStyle
local D = ViewpointInvData

local cross = getTexture("media/ui/inventoryPanes/Button_Close.png")
local CROSS = 14


function Dt.new(item, owner, player)
    local tip = ISToolTipInv:new(item)
    tip:initialise()
    tip:setOwner(owner)
    tip:setCharacter(player)
    tip.followMouse = false
    return setmetatable({ item = item, tip = tip }, Dt)
end

function Dt:gone()
    return self.item:getContainer() == nil and self.item:getWorldItem() == nil
end

function Dt:close()
    if self.shown then
        self.tip:removeFromUIManager()
        self.tip:setVisible(false)
        self.shown = false
    end
end


function Dt:place(x, y)
    self.tip:setX(x)
    self.tip:setY(y)
    if not self.shown then
        self.tip:addToUIManager()
        self.tip:setVisible(true)
        self.shown = true
    end
end


function Dt:head(ui, m, r, big)
    local item = self.item
    local x, y = r.x + m.pad, r.y + m.pad
    S.slotBox(ui, x, y, big, big)
    local icon = math.floor(big * 0.72)
    ui.javaObject:DrawItemIcon(item, x + math.floor((big - icon) / 2), y + math.floor((big - icon) / 2), 1.0, icon, icon)
    local tx = x + big + m.pad * 2
    local room = r.x + r.w - m.pad * 2 - CROSS - tx
    S.text(ui, S.fit(item:getDisplayName(), room, UIFont.Medium), tx, y, S.bright, nil, UIFont.Medium)
    local ly = y + getTextManager():getFontHeight(UIFont.Medium) + m.gap
    S.text(ui, S.fit(D.category(item), room), tx, ly, S.muted)
    ly = ly + m.font
    S.text(ui, getText("Tooltip_item_Weight") .. "  " .. S.weight(item:getUnequippedWeight()), tx, ly, S.muted)
    local condition = D.condition(item)
    if condition then
        ly = ly + m.font + m.gap
        S.bar(ui, tx, ly, room, m.bar + 1, condition, S.wholeness(condition))
        S.textRight(ui, math.floor(condition * 100 + 0.5) .. "%", r.x + r.w - m.pad, ly - math.floor(m.font / 2), S.muted)
    end
end


function Dt:render(ui, m, r, hover)
    self.rect = r
    S.rect(ui, r.x, r.y, r.w, r.h, S.panel, 0.97)
    S.edge(ui, r.x, r.y, r.w, r.h, S.panelEdge)
    local big = math.floor(math.min(r.w * 0.3, m.unit * 2.2))
    self:head(ui, m, r, big)
    local cx, cy = r.x + r.w - m.pad - CROSS, r.y + m.pad
    local over = hover and hover.kind == "detailsClose"
    S.icon(ui, cross, cx, cy, CROSS, over and 1 or 0.6)
    self.crossRect = { x = cx - 3, y = cy - 3, w = CROSS + 6, h = CROSS + 6 }
    self:place(ui:getAbsoluteX() + r.x + m.pad, ui:getAbsoluteY() + r.y + m.pad * 2 + big)
end


function Dt:hit(mx, my)
    local r, c = self.rect, self.crossRect
    if not r then return nil end
    if c and mx >= c.x and mx < c.x + c.w and my >= c.y and my < c.y + c.h then return { kind = "detailsClose" } end
    if mx >= r.x and mx < r.x + r.w and my >= r.y and my < r.y + r.h then return { kind = "details" } end
    return nil
end
