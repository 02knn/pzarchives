







require "ISUI/ISUI3DModel"
require "Viewpoint_InvStyle"
require "Viewpoint_InvData"

ViewpointInvGear = {}
local Gear = ViewpointInvGear
Gear.__index = Gear
local S = ViewpointInvStyle

local TITLE = "Equipment"

local ROW = 6


local DOT_W, DOT_H, DOT_FOOT = 0.9, 0.28, 0.4
local MIN_DOT, DOT_REACH, DOT_OFF = 2, 3, 0.5

local ARROW, ARROW_REACH = 0.75, 4


local SLOTS = {
    { id = "head", key = "UI_ClothingType_Hat", names = { "Hat", "FullHat", "FullSuitHead", "FullSuitHeadSCBA" } },
    { id = "face", key = "UI_ClothingType_Mask", names = { "Mask", "MaskEyes", "MaskFull", "Eyes", "LeftEye", "RightEye",
        "Nose", "Ears", "EarTop" } },
    { id = "neck", key = "UI_ClothingType_Neck", names = { "Neck", "Necklace", "Necklace_Long", "Scarf", "Gorget" } },
    { id = "jacket", key = "UI_ClothingType_Jacket", names = { "Jacket", "Jacket_Down", "Jacket_Bulky", "JacketHat",
        "JacketHat_Bulky", "JacketSuit", "FullSuit", "Boilersuit", "BathRobe", "FullRobe", "FullTop", "Sweater",
        "SweaterHat", "Jersey", "TorsoExtra", "TorsoExtraVest", "TorsoExtraVestBullet", "Cuirass", "SCBA",
        "SCBAnotank", "BodyCostume" } },
    { id = "shirt", key = "UI_ClothingType_Shirt", names = { "Shirt", "ShortSleeveShirt", "Tshirt", "TankTop", "Torso1",
        "Torso1Legs1", "Dress", "LongDress", "UnderwearTop" } },
    { id = "hands", key = "UI_ClothingType_Hands", names = { "Hands", "HandsLeft", "HandsRight", "LeftWrist",
        "RightWrist", "Right_MiddleFinger", "Left_MiddleFinger", "Left_RingFinger", "Right_RingFinger", "RightArm",
        "LeftArm", "ForeArm_Left", "ForeArm_Right", "Elbow_Left", "Elbow_Right" } },
    { id = "back", key = "UI_ClothingType_Back", names = { "Back", "Satchel" } },
    { id = "belt", key = "UI_ClothingType_Belt", names = { "Belt", "BeltExtra", "FannyPackFront", "FannyPackBack",
        "Webbing", "AmmoStrap", "ShoulderHolster", "AnkleHolster" } },
    { id = "legs", key = "UI_ClothingType_Pants", names = { "Pants", "Pants_Skinny", "PantsExtra", "ShortPants",
        "ShortsShort", "Skirt", "LongSkirt", "Legs1", "Legs5", "UnderwearBottom", "Underwear", "UnderwearExtra1",
        "UnderwearExtra2", "Codpiece" } },
    { id = "feet", key = "UI_ClothingType_Shoes", names = { "Shoes", "Socks", "Gaiter_Right", "Gaiter_Left" } },
    { id = "pads", label = "Pads", names = { "Knee_Left", "Knee_Right", "Calf_Left", "Calf_Right", "Thigh_Left",
        "Thigh_Right", "ShoulderpadRight", "ShoulderpadLeft", "SportShoulderpad", "SportShoulderpadOnTop" } },
    { id = "other", label = "Other", names = {} },
}


local HIDDEN = { bandage = true, wound = true, zeddmg = true, bellybutton = true }

local slotOf = {}
for _, slot in ipairs(SLOTS) do
    slot.label = slot.label or getText(slot.key)
    for _, n in ipairs(slot.names) do slotOf[string.lower(n)] = slot end
end


ViewpointInvAvatar = ISUI3DModel:derive("ViewpointInvAvatar")

function ViewpointInvAvatar:new(x, y, w, h)
    return ISUI3DModel.new(self, x, y, w, h)
end

function ViewpointInvAvatar:bind(player)
    self:setState("idle")
    self:setDirection(IsoDirections.S)
    self:setIsometric(false)
    self:setCharacter(player)
end


function Gear.new()
    return setmetatable({ worn = {}, shown = {}, hits = {}, x = 0, y = 0, w = 0, h = 0 }, Gear)
end



function Gear:shownAt(slot, items)
    local chosen = self.shown[slot.id]
    for k = 1, #items do
        if items[#items - k + 1] == chosen then return k end
    end
    return 1
end


function Gear:show(slot, k)
    local items = self.worn[slot.id]
    local item = items and items[#items - k + 1]
    if item then self.shown[slot.id] = item end
end


function Gear:step(slot, dir)
    local items = self.worn[slot.id]
    if not items or #items < 2 then return end
    local n = #items

    self:show(slot, (self:shownAt(slot, items) - 1 + dir + n) % n + 1)
end


function Gear:wheel(mx, my, del)
    local h = self:hit(mx, my)
    local items = h and h.slot and self.worn[h.slot.id]
    if not items or #items < 2 then return false end
    self:step(h.slot, del > 0 and 1 or -1)
    return true
end


function Gear:refresh(player)
    local worn = {}
    local items = player:getWornItems()
    for i = 0, items:size() - 1 do
        local entry = items:get(i)
        local name = string.lower(entry:getLocation():getTranslationName())
        if not HIDDEN[name] and not string.find(name, "^makeup") and not string.find(name, "_texture$") then
            local slot = slotOf[name] or SLOTS[#SLOTS]
            worn[slot.id] = worn[slot.id] or {}
            table.insert(worn[slot.id], entry:getItem())
        end
    end
    self.worn = worn
end



function Gear:layout(x, y, w, m)
    self.x, self.y, self.w, self.m = x, y, w, m
    local rows = math.ceil(#SLOTS / ROW)
    local inner = w - m.pad * 2 - m.gap * (ROW - 1)
    local size = math.min(math.floor(inner / ROW), math.floor(m.unit * 1.2))
    self.size = size
    local x0, y0 = x + m.pad, y + m.title + m.pad
    self.places = {}
    for i, slot in ipairs(SLOTS) do
        local col, row = (i - 1) % ROW, math.floor((i - 1) / ROW)

        local left = x0 + math.floor(inner * col / ROW) + col * m.gap
        local right = x0 + math.floor(inner * (col + 1) / ROW) + col * m.gap
        self.places[i] = { slot = slot, x = left, y = y0 + row * (size + m.gap), w = right - left }
    end
    self.h = m.title + m.pad * 2 + rows * size + (rows - 1) * m.gap
    self.dotW, self.dotH = math.max(8, math.floor(m.font * DOT_W)), math.max(3, math.floor(m.font * DOT_H))
    self.dotY = size - m.inset - math.max(3, math.floor(m.font * DOT_FOOT)) - self.dotH
    self.arrowSize = math.max(8, math.floor(m.font * ARROW))
    self.arrowY = m.inset + math.floor((self.dotY - m.inset - self.arrowSize) / 2)
    return self.h
end



local function slotBox(ui, m, x, y, w, h, item, label, count, foot, hover, drop)
    local condition = item and S.condition(ViewpointInvData.condition(item), item:isBroken())
    S.slotBox(ui, x, y, w, h, hover, drop and (drop.ok and S.drop or S.refuse), false, not item, condition)
    local inset = m.inset
    if not item then
        local cx, cy = x + math.floor(w / 2), y + math.floor((h - m.font) / 2)
        S.textCentre(ui, S.fit(label, w - inset * 2), cx, cy, S.dim)
        return
    end
    local icon = math.floor(h * 0.68)
    local iy = y + math.floor((h - icon) / 2)
    if count > 1 then
        icon = math.floor(h * 0.6)
        iy = y + inset + math.floor((foot - y - inset - icon) / 2)
    end
    ui.javaObject:DrawItemIcon(item, x + math.floor((w - icon) / 2), iy, 1.0, icon, icon)
end


local function pill(ui, x, y, w, h, c, a)
    S.rect(ui, x + 1, y, w - 2, 1, c, a)
    S.rect(ui, x, y + 1, w, h - 2, c, a)
    S.rect(ui, x + 1, y + h - 1, w - 2, 1, c, a)
end


local function on(hover, slot)
    local k = hover and hover.kind
    return (k == "slot" or k == "slotDot" or k == "slotStep") and hover.slot == slot
end



local function chevron(ui, x, y, h, dir, c)
    local w, t = math.floor(h / 2) + 1, math.max(2, math.floor(h / 6))
    local mid = (h - 1) / 2
    x = x + math.floor((h - w) / 2)
    for r = 0, h - 1 do
        local dx = math.floor(math.abs(r - mid) * (w - t) / mid + 0.5)
        S.rect(ui, dir < 0 and x + dx or x + w - t - dx, y + r, t, 1, c)
    end
end



function Gear:arrow(ui, place, dir, hover)
    local m, size = self.m, self.arrowSize
    local x = place.x + m.inset + math.floor(m.pad / 2)
    if dir > 0 then x = place.x + place.w - m.inset - math.floor(m.pad / 2) - size end
    local y = place.y + self.arrowY
    local over = hover and hover.kind == "slotStep" and hover.slot == place.slot and hover.dir == dir
    chevron(ui, x, y, size, dir, over and S.bright or S.muted)
    table.insert(self.hits, { x = x - ARROW_REACH, y = y - ARROW_REACH, w = size + ARROW_REACH * 2,
        h = size + ARROW_REACH * 2, target = { kind = "slotStep", slot = place.slot, dir = dir } })
end





function Gear:dots(ui, place, items, shown, hover)
    local n, h = #items, self.dotH
    local room = place.w - self.m.inset * 2
    local gap = math.max(2, math.floor(h * 0.8))
    if n * MIN_DOT + (n - 1) * gap > room then gap = math.max(0, math.floor((room - n * MIN_DOT) / (n - 1))) end
    local w = math.max(MIN_DOT, math.min(self.dotW, math.floor((room - gap * (n - 1)) / n)))
    local x = place.x + math.floor((place.w - n * w - (n - 1) * gap) / 2)
    local y = place.y + self.dotY
    for i = 1, n do
        local over = hover and hover.kind == "slotDot" and hover.slot == place.slot and hover.index == i
        pill(ui, x, y, w, h, i == shown and S.bright or S.dim, (i == shown or over) and 1 or DOT_OFF)
        table.insert(self.hits, { x = x - math.floor(gap / 2), y = y - DOT_REACH, w = w + gap, h = h + DOT_REACH * 2,
            target = { kind = "slotDot", slot = place.slot, index = i, item = items[n - i + 1] } })
        x = x + w + gap
    end
end

function Gear:render(ui, view)
    local m = self.m
    self.hits = { { x = self.x, y = self.y, w = self.w, h = self.h, target = { kind = "equipment" } } }
    S.window(ui, m, self.x, self.y, self.w, self.h, TITLE)
    local hover, drag = view.hover, view.drag
    for _, place in ipairs(self.places) do
        local slot = place.slot
        local items = self.worn[slot.id] or {}
        local n = #items
        local shown = n > 1 and self:shownAt(slot, items) or 1
        local item = items[n - shown + 1]
        local over = on(hover, slot)
        local drop = drag and over and { ok = drag.wearable }
        slotBox(ui, m, place.x, place.y, place.w, self.size, item, slot.label, n, place.y + self.dotY, over, drop)
        table.insert(self.hits, { x = place.x, y = place.y, w = place.w, h = self.size,
            target = { kind = "slot", slot = slot, items = items, item = item } })
        if n > 1 then
            self:dots(ui, place, items, shown, hover)
            self:arrow(ui, place, -1, hover)
            self:arrow(ui, place, 1, hover)
        end
    end
end

function Gear:hit(mx, my)
    for i = #self.hits, 1, -1 do
        local h = self.hits[i]
        if mx >= h.x and mx < h.x + h.w and my >= h.y and my < h.y + h.h then return h.target end
    end
    return nil
end
