



require "Viewpoint_InvStyle"

ViewpointInvView = {}
local V = ViewpointInvView
local S = ViewpointInvStyle

function V.inside(r, mx, my)
    return r ~= nil and mx >= r.x and my >= r.y and mx < r.x + r.w and my < r.y + r.h
end

function V.addHit(pane, x, y, w, h, target)
    table.insert(pane.hits, { x = x, y = y, w = w, h = h, target = target })
end


function V.addClipped(pane, r, x, y, w, h, target)
    local top, bottom = math.max(y, r.y), math.min(y + h, r.y + r.h)
    if bottom > top then V.addHit(pane, x, top, w, bottom - top, target) end
end



function V.panel(ui, pane, content)
    local a, m = pane.area, pane.m
    local h = content and math.min(a.h, content + m.pad * 4) or a.h
    pane.drawn = { x = a.x, y = a.y, w = a.w, h = h }
    S.box(ui, a.x, a.y, a.w, h)
end



function V.hit(pane, mx, my)
    if not V.inside(pane.drawn or pane.area, mx, my) then return nil end
    for i = #pane.hits, 1, -1 do
        local h = pane.hits[i]
        if V.inside(h, mx, my) then return h.target, h end
    end
    return { kind = "panel" }
end


function V.over(hover, kind, id)
    return hover ~= nil and hover.kind == kind and hover.id == id
end



function V.scroll(ui, pane, r, content)
    pane.most, pane.scrolled = math.max(0, content - r.h), r
    pane.scroll = math.max(0, math.min(pane.scroll, pane.most))
    if content <= r.h then return end
    local track = r.h * r.h / content
    local at = r.y + (r.h - track) * (pane.scroll / math.max(1, content - r.h))
    S.rect(ui, r.x + r.w + 1, at, 2, track, S.scrollBar)
end



function V.wheel(pane, delta)
    pane.scroll = math.max(0, math.min(pane.scroll + delta, pane.most or 0))
end


function V.button(ui, pane, r, label, target, hover, off)
    local over = not off and V.over(hover, target.kind, target.id)
    S.button(ui, pane.m, r.x, r.y, r.w, r.h, label, over, off)
    V.addHit(pane, r.x, r.y, r.w, r.h, target)
end


function V.header(ui, m, x, y, w, title)
    S.componentHeader(ui, x, y, w, m.header, false)
    S.text(ui, S.fit(S.caps(title), w - m.pad * 2), x + m.pad, y + m.pad, S.bright)
end



function V.blend(stops, value)
    local first = stops[1]
    if value <= first[1] then return { first[2], first[3], first[4], 1 } end
    for i = 2, #stops do
        local a, b = stops[i - 1], stops[i]
        if value <= b[1] then
            local t = (value - a[1]) / math.max(0.0001, b[1] - a[1])
            return { a[2] + (b[2] - a[2]) * t, a[3] + (b[3] - a[3]) * t, a[4] + (b[4] - a[4]) * t, 1 }
        end
    end
    local last = stops[#stops]
    return { last[2], last[3], last[4], 1 }
end
