








require "Viewpoint_InvStyle"
require "Viewpoint_InvView"
require "Viewpoint_InvBody"

ViewpointInvTabHealth = {}
local T = ViewpointInvTabHealth
T.__index = T
local S = ViewpointInvStyle
local V = ViewpointInvView
local B = ViewpointInvBody

local PLAYER = 0

local LIT_ALPHA = 0.4


local STATES = {
    { 90, "IGUI_health_Slight_damage" }, { 80, "IGUI_health_Very_Minor_damage" },
    { 70, "IGUI_health_Minor_damage" }, { 60, "IGUI_health_Moderate_damage" }, { 50, "IGUI_health_Severe_damage" },
    { 40, "IGUI_health_Very_Severe_damage" }, { 20, "IGUI_health_Crital_damage" },
    { 10, "IGUI_health_Highly_Crital_damage" }, { 0, "IGUI_health_Terminal_damage" },
}


local function stateWords(health)
    if health >= 100 then return getText("IGUI_health_ok") end
    for _, entry in ipairs(STATES) do
        if health > entry[1] then return getText(entry[2]) end
    end
    return getText("IGUI_health_Deceased")
end


local function model()
    local info = getPlayerInfoPanel(PLAYER)
    return info and info.healthView
end



local Row = {}
Row.__index = Row

function Row:drawText(str, x, y, r, g, b)
    table.insert(self.lines, { text = string.gsub(str, "^%s*%-%s*", ""), colour = { r, g, b, 1 }, job = self.job })
    self.job = nil
end

function Row:drawProgressBar(x, y, w, h, fraction)
    self.job = fraction
end

function Row:drawRect() end
function Row:drawRectBorder() end
function Row:drawTexture() end
function Row:drawTextureScaled() end

function Row:getWidth()
    return 0
end


local function lines(health, part)
    local row = setmetatable({ parent = health, lines = {}, selected = -1, mouseoverselected = -1, width = 0 }, Row)
    local entry = { item = { bodyPart = part }, itemindex = 0, height = 0 }
    if not pcall(ISHealthBodyPartListBox.doDrawItem, row, 0, entry, false) or #row.lines == 0 then
        row.lines = { { text = BodyPartType.getDisplayName(part:getType()), colour = S.bright } }
    end
    return row.lines
end

function T.new()
    return setmetatable({ scroll = 0, hits = {} }, T)
end



function T:layout(area, m)
    self.area, self.m = area, m
    local tm = getTextManager()
    self.line = tm:getFontHeight(UIFont.Medium) + 2
    self.head = { x = area.x + m.pad * 2, y = area.y + m.pad * 2, w = area.w - m.pad * 4 }
    self.head.h = self.line + m.pad + m.bar * 2
    self.footH = m.font + m.pad * 2
    local top = self.head.y + self.head.h + m.pad * 2
    self.room = area.y + area.h - self.footH - m.pad * 2 - top
    local s = B.fit(area.w * 0.42, self.room)
    self.scale = s
    self.figureH = math.ceil((B.H - B.TARGETS_Y) * s)
    self.origin = { x = area.x + m.pad * 2 - B.TARGETS_X * s, y = top - B.TARGETS_Y * s }
    local listX = area.x + m.pad * 3 + math.ceil((B.W - B.TARGETS_X * 2) * s)
    self.list = { x = listX, y = top, w = area.x + area.w - m.pad * 2 - listX, h = self.room }
    local label = getText("ContextMenu_Fitness")
    local bw = tm:MeasureStringX(UIFont.Small, label) + m.pad * 4
    self.exercise = { x = area.x + area.w - m.pad * 2 - bw, y = 0, w = bw, h = m.font + m.pad }
end



function T:fit()
    local m, list = self.m, self.list
    list.h = math.min(self.room, math.max(self.figureH, self.cardsH or 0))
    self.footY = list.y + list.h + m.pad
    self.exercise.y = self.footY + math.floor((self.footH - self.exercise.h) / 2)
    self.content = self.footY + self.footH - self.area.y - m.pad * 3
end

function T:status(ui, player)
    local m, r = self.m, self.head
    local health = player:getBodyDamage():getHealth()
    local fraction = health / 100
    local colour = S.wholeness(fraction)
    S.text(ui, S.caps(getText("IGUI_health_Overall_Body_Status")), r.x, r.y + self.line - m.font - 2, S.muted)
    S.textRight(ui, stateWords(health), r.x + r.w, r.y, colour, nil, UIFont.Medium)
    S.bar(ui, r.x, r.y + r.h - m.bar * 2, r.w, m.bar * 2, fraction, colour)
end



function T:figure(ui, player, lit, dragging)
    local f = B.textures(player:isFemale())
    local o, s, x, y = ui.javaObject, self.scale, self.origin.x, self.origin.y
    B.health(o, f, player, x, y, s)
    local light = dragging and S.drop or S.bright
    local function tint(i)
        if B.part(player, i) == lit then return light, LIT_ALPHA end
        return nil
    end
    local function add(hx, hy, hw, hh, i)
        V.addHit(self, hx, hy, hw, hh, { kind = "part", part = B.part(player, i), label = B.name(i) })
    end
    B.shapes(o, f, x + B.TARGETS_X * s, y + B.TARGETS_Y * s, s, tint, add)
end


function T:card(ui, rows, x, y, w, h, lit, dragging)
    local m, line = self.m, self.line
    S.rect(ui, x, y, w, h, S.tile)
    S.edge(ui, x, y, w, h, S.panelEdge)
    S.componentHeader(ui, x, y, w, m.header, lit)
    S.text(ui, S.fit(S.caps(rows[1].text), w - m.pad * 2), x + m.pad, y + m.pad, S.bright)
    if lit and dragging then S.edge(ui, x, y, w, h, S.drop) end
    local ly = y + m.header + math.floor(m.pad / 2)
    local tx = x + m.pad * 2 + m.bar
    for i = 2, #rows do
        local row = rows[i]
        if row.job then S.bar(ui, tx, ly + 1, w - (tx - x) - m.pad, line - 2, row.job, S.accent) end
        S.rect(ui, x + m.pad, ly + math.floor((line - m.bar) / 2), m.bar, m.bar, row.colour)
        S.text(ui, S.fit(row.text, w - (tx - x) - m.pad, UIFont.Medium), tx, ly, row.colour, nil, UIFont.Medium)
        ly = ly + line
    end
end


function T:cards(ui, health, lit, dragging)
    local m, r = self.m, self.list
    ui:setStencilRect(r.x, r.y, r.w, r.h)
    local y = r.y - self.scroll
    for _, part in ipairs(health:getDamagedParts()) do
        local rows = lines(health, part)
        local h = m.header + (#rows - 1) * self.line + m.pad
        if y + h > r.y and y < r.y + r.h then
            self:card(ui, rows, r.x, y, r.w, h, part == lit, dragging)
            V.addClipped(self, r, r.x, y, r.w, h, { kind = "part", part = part })
        end
        y = y + h + m.pad
    end
    ui:clearStencilRect()
    self.cardsH = y + self.scroll - r.y - m.pad
    V.scroll(ui, self, r, self.cardsH + m.pad)
end

function T:footer(ui, view)
    local m, b = self.m, self.exercise
    local hint = S.fit(getText("IGUI_health_RightClickTreatement"), b.x - self.area.x - m.pad * 4)
    S.text(ui, hint, self.area.x + m.pad * 2, self.footY + math.floor((self.footH - m.font) / 2), S.dim)
    V.button(ui, self, b, getText("ContextMenu_Fitness"), { kind = "exercise", view = self }, view.hover)
end


function T:render(ui, view)
    local m = self.m
    self.hits = {}
    if not m then return end
    self:fit()
    V.panel(ui, self, self.content)
    local player, health = getSpecificPlayer(PLAYER), model()
    if not (player and health) then return end
    health.doctorLevel = player:getPerkLevel(Perks.Doctor)
    local lit = view.hover and view.hover.kind == "part" and view.hover.part or nil
    local dragging = view.drag ~= nil
    self:status(ui, player)
    self:figure(ui, player, lit, dragging)
    self:cards(ui, health, lit, dragging)
    self:footer(ui, view)
end


function T:hit(mx, my)
    return V.hit(self, mx, my)
end

function T:wheel(mx, my, del)
    if not V.inside(self.list, mx, my) then return false end
    V.wheel(self, del * self.line * 2)
    return true
end





function T:click(h)
    local health = model()
    if h.kind ~= "exercise" or not health then return end
    ISNewHealthPanel.onClick({ playerNum = -1, character = health.character }, { internal = "FITNESS" })
end


function T:apply(part, items)
    local health = model()
    if health then health:dropItemsOnBodyPart(part, items) end
end


function T:menu(part, x, y)
    local health = model()
    if not health or (UIManager.getSpeedControls():getCurrentGameSpeed() == 0 and not getDebug()) then return end
    health.doctorLevel = getSpecificPlayer(PLAYER):getPerkLevel(Perks.Doctor)
    health:doBodyPartContextMenu(part, x - health:getAbsoluteX(), y - health:getAbsoluteY())
end
