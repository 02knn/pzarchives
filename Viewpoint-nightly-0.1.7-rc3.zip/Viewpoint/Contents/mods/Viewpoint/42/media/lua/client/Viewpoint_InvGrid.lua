



















require "Viewpoint_InvStyle"
require "Viewpoint_InvData"
require "Viewpoint_InvFilter"
require "Viewpoint_InvList"

ViewpointInvGrid = {}
local G = ViewpointInvGrid
G.__index = G
local S = ViewpointInvStyle
local D = ViewpointInvData
local L = ViewpointInvList

local folded = getTexture("media/ui/inventoryPanes/Button_TreeCollapsed.png")
local unfolded = getTexture("media/ui/inventoryPanes/Button_TreeExpanded.png")
local favourite = getTexture("media/ui/FavoriteStar.png")
local broken = getTexture("media/ui/icon_broken.png")
local mannequin = getTexture("media/ui/Container_Mannequin.png")

local ARROW, ARROW_REACH = 10, 2



function G.new(title, mine, grows)
    return setmetatable({ title = title, mine = mine, grows = grows, sections = {}, scroll = 0, hits = {}, query = "",
        order = D.ORDERS[1], filter = ViewpointInvFilter.new(), list = false, x = 0, y = 0, w = 0, h = 0, room = 0 }, G)
end



function G:listFrom(v)
    local list = v.listed(self.mine)
    if list == self.list then return end
    self.list = list
    self.scroll = 0
    if self.m then self:layout(self.x, self.y, self.w, self.room, self.m) end
end




function G:click(h)
    if h.kind == "layout" then
        local v = Viewpoint and Viewpoint.Inventory
        if v then v.setListed(self.mine, h.list) else self.list = h.list end
    elseif h.kind == "equipped" then
        self.equipped = not self.equipped
    end
end



function G:addEquipped(player)
    local s = self.equippedSection or { title = "Equipped", icon = mannequin, equipped = true, mine = true, open = {},
        stacks = {} }
    s.container, s.count, s.weight = player:getInventory(), -1, -1
    self.equippedSection = s
    table.insert(self.sections, s)
end


function G:narrowed()
    return self.query ~= "" or self.filter:narrows()
end




function G:lists(s)
    if self.equipped or s.equipped then return self.equipped == true and s.equipped == true end
    return self.alone == nil or s.container == self.alone or s.within == self.alone
end







function G:layout(x, y, w, h, m)
    self.x, self.y, self.w, self.h, self.room, self.m = x, y, w, h, h, m
    local across = w - m.pad * 2 + m.gap
    self.cols = math.max(1, math.floor(across / (m.tile + m.gap) + 0.5))
    self.tile = math.floor(across / self.cols) - m.gap
    self.x0 = x + m.pad + math.floor((across - self.cols * (self.tile + m.gap)) / 2)
    local widest = 0
    for _, order in ipairs(D.ORDERS) do
        widest = math.max(widest, getTextManager():MeasureStringX(UIFont.Small, order.label))
    end
    local row = m.font + m.pad * 2
    local bh = m.font + m.pad
    local by = y + m.title + math.floor((row - bh) / 2)
    self.listRect = { x = x + w - m.pad - bh, y = by, w = bh, h = bh }
    self.gridRect = { x = self.listRect.x - bh + 1, y = by, w = bh, h = bh }
    local ow = widest + m.pad * 4 + 10 + 7
    self.orderRect = { x = self.gridRect.x - m.pad - ow, y = by, w = ow, h = bh }
    local fw = getTextManager():MeasureStringX(UIFont.Small, ViewpointInvFilter.WIDEST) + m.pad * 3 + 10
    self.filterRect = { x = self.orderRect.x - m.pad - fw, y = by, w = fw, h = bh }
    self.searchRect = { x = x + m.pad, y = by, w = self.filterRect.x - m.pad * 2 - x, h = bh }
    self.bodyTop = y + m.title + row
    if self.list then L.layout(self) end
end


function G:nextOrder()
    for i, order in ipairs(D.ORDERS) do
        if order == self.order or order.flip == self.order then
            self.order = D.ORDERS[i % #D.ORDERS + 1]
            return
        end
    end
    self.order = D.ORDERS[1]
end


function G:reverseOrder()
    self.order = self.order.flip
end

function G:contains(mx, my)
    return mx >= self.x and mx < self.x + self.w and my >= self.y and my < self.y + self.h
end


function G:scrollBy(px)
    self.scroll = math.max(0, math.min(self.scroll + px, self.most or 0))
end

function G:wheel(del)
    self:scrollBy(del * (self.list and self.lm.row or self.tile + self.m.gap))
end


function G:floor()
    for _, s in ipairs(self.sections) do
        if s.floor then return s end
    end
    return nil
end







function G.tile(ui, m, x, y, size, item, count, state, job, look)
    look = look or D.look(item)
    S.slotBox(ui, x, y, size, size, state.hover, state.edge, state.selected, false,
        S.condition(look.condition, look.broken))
    local inset = m.inset
    local inner = size - inset * 2
    local kind = S.typeTint(look.junk and D.JUNK or look.type)
    if kind then S.rect(ui, x + inset, y + inset, inner, inner, kind) end
    if job and job > 0 then S.rect(ui, x + inset, y + inset, math.floor(inner * job), inner, S.job) end
    local icon = math.floor(size * 0.6)
    local alpha = state.dim and 0.45 or 1.0
    ui.javaObject:DrawItemIcon(item, x + math.floor((size - icon) / 2), y + math.floor((size - icon) / 2) - 2, alpha, icon, icon)
    local bottom = y + size - inset
    local amount = look.amount
    if amount then
        local fill = math.floor((inner - 2) * math.max(0, math.min(1, amount)))
        if fill > 0 then S.rect(ui, x + inset + 1, bottom - 3, fill, 2, S.amount) end
        bottom = bottom - 3
    end
    if count and count > 1 then S.textRight(ui, tostring(count), x + size - inset - 2, bottom - m.font, S.bright) end
    if state.slot then S.text(ui, tostring(state.slot), x + inset + 2, y + inset, S.accent) end
    local mark = look.broken and broken or (look.favourite and favourite or nil)
    if mark then S.icon(ui, mark, x + size - inset - 12, y + inset + 1, 11) end
end

local function hit(self, x, y, w, h, target)
    table.insert(self.hits, { x = x, y = y, w = w, h = h, target = target })
end


local function itemsHeight(self, shown)
    local m = self.m
    if self.list then return L.height(self, shown) end
    if #shown == 0 then return m.font + m.gap * 2 end
    return m.gap + math.ceil(#shown / self.cols) * (self.tile + m.gap)
end


function G:contentHeight()
    local m = self.m
    local narrowed = self:narrowed()
    local height = 0
    for _, s in ipairs(self.sections) do
        local shown = self:lists(s) and D.shown(s, self.query, self.order, self.filter)
        if shown and (not narrowed or #shown > 0) then
            height = height + m.header + m.pad
            if narrowed or not s.folded then height = height + itemsHeight(self, shown) end
        end
    end
    return height
end




function G:header(ui, s, shown, x, y, w, view)
    local m = self.m
    local over = view.hover and view.hover.section == s
    hit(self, x, y, w, m.header, { kind = "header", section = s })
    hit(self, x, y, m.pad + 16, m.header, { kind = "fold", section = s })
    S.componentHeader(ui, x, y, w, m.header, over)
    if not s.equipped and (s.container == view.across or s.container == view.into) then
        S.rect(ui, x + 1, y + 1, 2, m.header - 2, S.accent)
    end
    local cx = x + m.pad
    S.icon(ui, s.folded and folded or unfolded, cx, y + math.floor((m.header - 12) / 2), 12)
    cx = cx + 16
    local iconSize = m.header - 4
    if s.icon then
        local tint = s.tint
        S.icon(ui, s.icon, cx, y + 2, iconSize, 1, tint and tint.r, tint and tint.g, tint and tint.b)
    end
    if s.lock then S.icon(ui, s.lock, cx + iconSize - 10, y + iconSize - 8, 10) end
    cx = cx + iconSize + m.pad
    local load, capacity = D.load(s, view.player)
    local drag = view.drag and over and not view.hover.into and view.drag
    if drag then load = load + drag.weight end
    local weight = capacity > 0 and (S.weight(load) .. " / " .. S.weight(capacity)) or S.weight(load)
    local right = x + w - m.pad
    S.textRight(ui, weight, right, y + m.pad, drag and (drag.fits[s] and S.good or S.bad) or S.muted)
    right = right - getTextManager():MeasureStringX(UIFont.Small, weight) - m.pad * 2
    if not self.mine and not s.locked and #s.stacks > 0 then
        local label = getText("IGUI_invpage_Loot_all")
        local bw = getTextManager():MeasureStringX(UIFont.Small, label) + m.pad * 2
        local bx = right - bw
        local bover = view.hover and view.hover.kind == "takeAll" and view.hover.section == s
        S.button(ui, m, bx, y + 2, bw, m.header - 4, label, bover, false, true)
        hit(self, bx, y + 2, bw, m.header - 4, { kind = "takeAll", section = s, stacks = self:narrowed() and shown or nil })
        right = bx - m.pad
    end
    local items = 0
    for _, stack in ipairs(shown) do items = items + stack.count end
    if items > 0 and not s.locked then
        local count = items == 1 and "1 item" or (items .. " items")
        local countW = getTextManager():MeasureStringX(UIFont.Small, count)
        if right - countW - m.pad > cx + m.font * 3 then
            S.textRight(ui, count, right, y + m.pad, S.muted)
            right = right - countW - m.pad * 2
        end
    end
    S.text(ui, S.fit(S.caps(s.title), right - cx), cx, y + m.pad, s.locked and S.dim or S.bright)
    if capacity > 0 then
        local fraction = load / capacity
        S.bar(ui, x, y + m.header - 2, w, 2, fraction, drag and (drag.fits[s] and S.drop or S.refuse) or S.fullness(fraction))
    end
    if drag then S.edge(ui, x, y, w, m.header, drag.fits[s] and S.drop or S.refuse) end
end



local function arrow(self, ui, s, stack, x, y, size)
    local ax, ay = x + self.m.inset + 1, y + size - self.m.inset - ARROW - 4
    S.icon(ui, stack.group and unfolded or folded, ax, ay, ARROW)
    local reach = ARROW + ARROW_REACH * 2
    hit(self, ax - ARROW_REACH, ay - ARROW_REACH, reach, reach, { kind = "stackArrow", section = s, stack = stack })
end


function G:tiles(ui, s, stacks, top, bottomEdge, view)
    local m = self.m
    local size, step = self.tile, self.tile + m.gap
    local x0 = self.x0
    if #stacks == 0 then
        if not s.locked then S.text(ui, getText("Fluid_Empty"), x0 + m.pad, top + m.gap, S.dim) end
        return itemsHeight(self, stacks)
    end
    local selected = view.selected[s.container]
    local working = not view.player:getCharacterActions():isEmpty()
    for i, stack in ipairs(stacks) do
        local col, row = (i - 1) % self.cols, math.floor((i - 1) / self.cols)
        local tx, ty = x0 + col * step, top + m.gap + row * step
        if ty + size >= self.bodyTop and ty <= bottomEdge then
            local state = {
                hover = view.hover and view.hover.stack == stack,
                selected = selected and selected[stack.key],
                dim = stack.unwanted,
                slot = stack.slot,
            }
            local into = state.hover and view.drag and view.hover.into
            if into then state.edge = view.drag.bags[into] and S.drop or S.refuse end
            local job = working and D.job(stack) or nil
            G.tile(ui, m, tx, ty, size, stack.item, stack.count, state, job, stack.look)
            hit(self, tx, ty, size, size, { kind = "tile", section = s, stack = stack })
            if stack.count > 1 or stack.group then arrow(self, ui, s, stack, tx, ty, size) end
        end
    end
    return itemsHeight(self, stacks)
end



function G:orderButton(ui, view)
    local m, r = self.m, self.orderRect
    local over = view.hover and view.hover.kind == "order" and view.hover.grid == self
    S.button(ui, m, r.x, r.y, r.w, r.h, "", over)
    local colour = (S.modern and not over) and S.muted or S.bright
    local label = S.fit(self.order.label, r.w - m.pad * 3 - 10 - (self.order.back and 7 + m.pad or 0))
    S.text(ui, label, r.x + m.pad, r.y + math.floor((r.h - m.font) / 2), colour)
    if self.order.back then
        local tx = r.x + m.pad * 2 + getTextManager():MeasureStringX(UIFont.Small, label)
        S.triangle(ui, tx, r.y + math.floor((r.h - 4) / 2), 7, self.order.up, colour)
    end
    S.icon(ui, unfolded, r.x + r.w - m.pad - 10, r.y + math.floor((r.h - 10) / 2), 10)
end



function G:filterButton(ui, view)
    local m, r = self.m, self.filterRect
    local over = view.hover and view.hover.kind == "filter" and view.hover.grid == self
    S.button(ui, m, r.x, r.y, r.w, r.h, "", over)
    local colour = self.filter:narrows() and S.accent or ((S.modern and not over) and S.muted or S.bright)
    S.text(ui, self.filter:label(), r.x + m.pad, r.y + math.floor((r.h - m.font) / 2), colour)
    S.icon(ui, unfolded, r.x + r.w - m.pad - 10, r.y + math.floor((r.h - 10) / 2), 10)
end







function G:switcher(ui, view)
    local m = self.m
    local size = m.title - 4
    local x, y = self.x + self.w - m.pad - size, self.y + 2
    local order = {}
    for _, s in ipairs(self.sections) do
        if not s.keyRing and not s.bag and not s.equipped then table.insert(order, s) end
    end
    for _, s in ipairs(self.sections) do
        if s.keyRing then table.insert(order, s) end
    end
    self.switch = {}
    for i = #order, 1, -1 do
        local s = order[i]
        local chosen = s.container == view.into
        local lit = chosen and not self.equipped
        local over = view.hover and view.hover.kind == "into" and view.hover.section == s
        if lit or over then S.rect(ui, x - 1, y - 1, size + 2, size + 2, lit and S.accent or S.wash, 0.3) end
        local tint = s.tint
        S.icon(ui, s.icon, x, y, size, 1, tint and tint.r, tint and tint.g, tint and tint.b)
        if chosen then S.edge(ui, x - 1, y - 1, size + 2, size + 2, S.accent) end
        table.insert(self.switch, { x = x, y = y, w = size, h = size, section = s })
        x = x - size - 2
    end
    local over = view.hover and view.hover.kind == "equipped" and view.hover.grid == self
    if self.equipped or over then
        S.rect(ui, x - 1, y - 1, size + 2, size + 2, self.equipped and S.accent or S.wash, 0.3)
    end
    S.icon(ui, mannequin, x, y, size)
    if self.equipped then S.edge(ui, x - 1, y - 1, size + 2, size + 2, S.accent) end
    self.equippedRect = { x = x, y = y, w = size, h = size }
end



function G:sectionsAt(ui, y, bottomEdge, view)
    local m = self.m
    local w = self.w - m.pad * 2
    local narrowed = self:narrowed()
    for _, s in ipairs(self.sections) do
        local shown = self:lists(s) and D.shown(s, self.query, self.order, self.filter)
        if shown and (not narrowed or #shown > 0) then
            if y + m.header >= self.bodyTop and y <= bottomEdge then
                self:header(ui, s, shown, self.x + m.pad, y, w, view)
            end
            y = y + m.header
            if narrowed or not s.folded then

                local space = { kind = "section", section = s, grid = self }
                hit(self, self.x + m.pad, y, w, itemsHeight(self, shown), space)
                if self.list then
                    y = y + L.rows(self, ui, s, shown, y, bottomEdge, view)
                else
                    y = y + self:tiles(ui, s, shown, y, bottomEdge, view)
                end
            end
            y = y + m.pad
        end
    end
    return y
end



function G:render(ui, view)
    local m = self.m
    self.hits = {}
    local chosen = D.chosen(self, view.selected)
    local footH = #chosen > 0 and m.header + m.pad or 0
    local bottom = self.y + self.room
    if self.grows then bottom = math.min(bottom, self.bodyTop + self:contentHeight() + footH) end
    self.h = bottom - self.y
    S.window(ui, m, self.x, self.y, self.w, self.h, self.title)
    self:filterButton(ui, view)
    self:orderButton(ui, view)
    L.switch(self, ui, view)
    if self.mine then self:switcher(ui, view) end
    local bodyH = math.min(self.y + self.room - m.pad, bottom) - footH - self.bodyTop
    local bottomEdge = self.bodyTop + bodyH
    self.body = { x = self.x, y = self.bodyTop, w = self.w, h = bodyH }
    ui:setStencilRect(self.x, self.bodyTop, self.w, bodyH)
    local y = self:sectionsAt(ui, self.bodyTop - self.scroll, bottomEdge, view)
    ui:clearStencilRect()
    local content = y + self.scroll - self.bodyTop
    self.most = math.max(0, content - bodyH)
    self.scroll = math.max(0, math.min(self.scroll, self.most))
    if content > bodyH then
        local track = bodyH * bodyH / content
        local at = self.bodyTop + (bodyH - track) * (self.scroll / math.max(1, content - bodyH))
        S.rect(ui, self.x + self.w - 4, at, 2, track, S.scrollBar)
    end
    if footH > 0 then self:footer(ui, view, chosen, bottomEdge + m.pad) end
end




function G:footer(ui, view, chosen, y)
    local m = self.m
    local x, w, h = self.x + m.pad, self.w - m.pad * 2, m.header
    hit(self, x, y, w, h, { kind = "footer", grid = self })
    S.rect(ui, x, y - 1, w, 1, S.panelEdge)
    local right = x + w
    local send = getText(self.mine and "ContextMenu_Drop" or "ContextMenu_Grab")
    for _, b in ipairs({ { "sendSelected", send, true }, { "clearSelected", getText("UI_chat_Clear"), false } }) do
        local kind, label = b[1], b[2]
        local bw = getTextManager():MeasureStringX(UIFont.Small, label) + m.pad * 2
        local over = view.hover and view.hover.kind == kind and view.hover.grid == self
        S.button(ui, m, right - bw, y + 2, bw, h - 4, label, over, false, b[3])
        hit(self, right - bw, y + 2, bw, h - 4, { kind = kind, grid = self })
        right = right - bw - m.pad
    end
    local items, load = 0, 0
    for _, stack in ipairs(chosen) do items, load = items + stack.count, load + stack.weight end
    local text = S.fit(items .. " selected, " .. S.weight(load) .. " weight", right - x - m.pad)
    S.text(ui, text, x + m.pad, y + math.floor((h - m.font) / 2), S.muted)
end


function G:tilesIn(r)
    local list = {}
    for _, h in ipairs(self.hits) do
        local t = h.target
        if t.kind == "tile" and h.x < r.x + r.w and r.x < h.x + h.w and h.y < r.y + r.h and r.y < h.y + h.h then
            table.insert(list, t)
        end
    end
    return list
end

local function within(r, mx, my)
    return r and mx >= r.x and mx < r.x + r.w and my >= r.y and my < r.y + r.h
end




function G:hit(mx, my)
    if not self:contains(mx, my) then return nil end
    if within(self.orderRect, mx, my) then return { kind = "order", grid = self } end
    if within(self.filterRect, mx, my) then return { kind = "filter", grid = self } end
    if within(self.gridRect, mx, my) then return { kind = "layout", grid = self, list = false, view = self } end
    if within(self.listRect, mx, my) then return { kind = "layout", grid = self, list = true, view = self } end
    if self.mine and within(self.equippedRect, mx, my) then return { kind = "equipped", grid = self, view = self } end
    for _, b in ipairs(self.mine and self.switch or {}) do
        if mx >= b.x and mx < b.x + b.w and my >= b.y and my < b.y + b.h then
            return { kind = "into", section = b.section, grid = self }
        end
    end
    if my >= (self.bodyTop or self.y) then
        for i = #self.hits, 1, -1 do
            local h = self.hits[i]
            if mx >= h.x and mx < h.x + h.w and my >= h.y and my < h.y + h.h then return h.target end
        end
    end
    return { kind = "column", grid = self }
end
