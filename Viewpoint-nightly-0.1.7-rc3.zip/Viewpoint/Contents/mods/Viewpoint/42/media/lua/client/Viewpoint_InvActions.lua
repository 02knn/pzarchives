




require "ISUI/ISInventoryPane"
require "ISUI/ISInventoryPaneContextMenu"

ViewpointInvActions = {}
local A = ViewpointInvActions
local CM = ISInventoryPaneContextMenu

local PLAYER = 0


local pane = setmetatable({ player = PLAYER }, { __index = ISInventoryPane })

local function playerObj()
    return getSpecificPlayer(PLAYER)
end

local function inCharacter(container, player)
    return container ~= nil and container:isInCharacterInventory(player)
end



function A.allowed(item, dest, player)
    if dest == nil or item:getContainer() == dest or dest:isInside(item) then return false end
    if dest:getType() == "floor" then return item:getWorldItem() == nil and not item:isFavorite() end
    if item:isFavorite() and not inCharacter(dest, player) then return false end
    return dest:isItemAllowed(item)
end





local function roomFor(dest, player, weight, outside)
    if dest:getType() == "floor" then return true end
    if not dest:hasRoomFor(player, weight) then return false end
    local bag = dest:getContainingItem()
    local wearer = bag and bag:getEquipParent()
    return wearer == nil or outside <= 0 or wearer:getInventory():hasRoomFor(player, outside)
end



function A.fitting(items, dest)
    local player = playerObj()
    local main = player:getInventory()
    local list = {}
    for _, item in ipairs(items) do
        if A.allowed(item, dest, player) then table.insert(list, item) end
    end
    local weight, outside, n = 0, 0, 0
    for _, item in ipairs(list) do
        local w = item:getUnequippedWeight()
        weight = weight + w
        if not main:contains(item) then outside = outside + w end
        if not roomFor(dest, player, weight, outside) then break end
        n = n + 1
    end
    return list, n
end




function A.move(items, dest)
    local player = playerObj()
    local list, n = A.fitting(items, dest)
    if n < #list then
        print(string.format("[Viewpoint] inventory: %d of %d items have no room in %s (%.1f of %d carried)", #list - n,
            #list, dest:getType(), dest:getCapacityWeight(), dest:getEffectiveCapacity(player)))
    end
    if n == 0 then return end
    if n < #list then
        local fit = {}
        for i = 1, n do fit[i] = list[i] end
        list = fit
    end
    if #list == 1 and isForceDropHeavyItem(list[1]) and dest == player:getInventory() then
        CM.equipHeavyItem(player, list[1])
        return
    end
    local far = inCharacter(dest, player) and list[1]:getContainer() or dest
    if dest:getType() ~= "floor" and not luautils.walkToContainer(far, PLAYER) then return end
    pane:transferItemsByWeight(list, dest)
end



function A.take(items, into)
    A.move(items, into or playerObj():getInventory())
end




function A.takeAll(container, only, into)
    local player = playerObj()
    local candidates = only
    if not candidates then
        candidates = {}
        local items = container:getItems()
        for i = 0, items:size() - 1 do table.insert(candidates, items:get(i)) end
    end
    local list, heavy = {}, nil
    for _, item in ipairs(candidates) do
        if not item:isHidden() and not item:isUnwanted(player) then
            if isForceDropHeavyItem(item) then heavy = item else table.insert(list, item) end
        end
    end
    if #list == 0 and heavy and #candidates == 1 then list = { heavy } end
    if #list > 0 then A.move(list, into or player:getInventory()) end
end

function A.drop(items)
    CM.onDropItems(items, PLAYER)
end

function A.wearable(item)
    if item:IsClothing() then return not item:isBroken() end
    local slot = item:canBeEquipped()
    return item:IsInventoryContainer() and slot ~= nil and slot ~= ""
end

function A.wear(item)
    CM.onWearItems({ item }, PLAYER)
end


function A.hold(item, primary)
    local player = playerObj()
    if isForceDropHeavyItem(item) then
        CM.equipHeavyItem(player, item)
        return
    end
    CM.equipWeapon(item, primary, item:isTwoHandWeapon() or item:isRequiresEquippedBothHands(), PLAYER)
end


function A.equip(item)
    local player = playerObj()
    if player:isEquipped(item) then
        A.unequip(item)
    elseif A.wearable(item) then
        A.wear(item)
    else
        A.hold(item, true)
    end
end

function A.unequip(item)
    CM.onUnEquip({ item }, PLAYER)
end


function A.use(item)
    ISInventoryPane.doContextualDblClick(pane, item)
end



function A.attachable(items, index)
    local hotbar = getPlayerHotbar(PLAYER)
    local slot = hotbar and hotbar.availableSlot[index]
    if not slot then return nil end
    for _, item in ipairs(items) do
        if hotbar.attachedItems[index] ~= item and hotbar:canBeAttached(slot, item) then return item end
    end
    return nil
end


function A.attach(items, index)
    local item = A.attachable(items, index)
    if not item then return false end
    local hotbar = getPlayerHotbar(PLAYER)
    local slot = hotbar.availableSlot[index]
    hotbar:attachItem(item, slot.def.attachments[item:getAttachmentType()], index, slot.def, true)
    return true
end


function A.menu(items, x, y)
    if #items == 0 then return nil end
    local player = playerObj()
    return CM.createMenu(PLAYER, inCharacter(items[1]:getContainer(), player), items, x, y)
end
