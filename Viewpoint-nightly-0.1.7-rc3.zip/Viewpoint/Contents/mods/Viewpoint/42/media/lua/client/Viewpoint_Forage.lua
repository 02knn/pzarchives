









ViewpointForage = {}

local UNKNOWN = "media/textures/Foraging/pinIconUnknown.png"
local POISON = "media/ui/SkullPoison.png"

local function viewOn()
    return Viewpoint and Viewpoint.Loot and Viewpoint.Loot.viewOn()
end


local function searching(player)
    local manager = ISSearchManager and ISSearchManager.getManager(player)
    return manager and manager.isSearchMode and manager or nil
end





function ViewpointForage.found(player, reach)
    local manager = searching(player)
    if not manager then return nil end
    local out, x, y, z = {}, player:getX(), player:getY(), player:getZ()
    local unknown, poison = getTexture(UNKNOWN), getTexture(POISON)
    for id, icon in pairs(manager.activeIcons) do
        local shown = icon:getIsSeen() and not icon.isTrack and math.floor(icon.zCoord) == math.floor(z)
                and math.abs(icon.xCoord + 0.5 - x) <= reach and math.abs(icon.yCoord + 0.5 - y) <= reach
        local pointed = icon.worldMarker ~= nil
        if shown or pointed then
            local known = icon.itemTexture and icon.identified and icon.renderItemTexture
            out[#out + 1] = id
            out[#out + 1] = icon.xCoord
            out[#out + 1] = icon.yCoord
            out[#out + 1] = icon.zCoord
            out[#out + 1] = known and icon.texture or unknown
            out[#out + 1] = known and icon.itemTexture or false
            out[#out + 1] = known and icon.isKnownPoison and poison or false
            out[#out + 1] = shown and true or false
            out[#out + 1] = pointed
        end
    end
    return out
end


function ViewpointForage.harvest(player, id)
    local manager = searching(player)
    local icon = manager and manager.activeIcons[id]
    if not icon then return { why = "the find is gone" } end
    local playerNum = player:getPlayerNum()
    local open, why = ViewpointInteract.menu(playerNum)
    if not open then return { why = why } end
    local context = ISContextMenu.get(playerNum, 0, 0)
    local ok, err = pcall(icon.doContextMenu, icon, context)
    local list, state = {}, ViewpointInteract.state(nil, nil)
    state.everything = true
    if ok then ViewpointInteract.collect(context, 0, nil, list, state) end
    for _, a in ipairs(list) do a.name = ViewpointInteract.label(a, state.title) end
    open:hideAndChildren()
    if not ok then error(err) end
    icon:getGridSquare()
    ViewpointInteract.target = { square = icon.square }
    return ViewpointInteract.finish(list, state.title, state.seen or 0)
end





local function wrapIcons()
    if not ISBaseIcon or ISBaseIcon.viewpointWrapped then return end
    local render, updateWorldMarker = ISBaseIcon.render, ISBaseIcon.updateWorldMarker
    ISBaseIcon.render = function(self)
        if viewOn() then return end
        return render(self)
    end
    ISBaseIcon.updateWorldMarker = function(self)
        updateWorldMarker(self)
        if self.worldMarker then self.worldMarker:setActive(not viewOn()) end
    end
    ISBaseIcon.viewpointWrapped = true
end




local function wrapOverlay()
    if not ISSearchManager or ISSearchManager.viewpointWrapped then return end
    local updateOverlay = ISSearchManager.updateOverlay
    ISSearchManager.updateOverlay = function(self)
        if not viewOn() then return updateOverlay(self) end
        local searching, effect = self.isSearchMode, self.isEffectOverlay
        self.isSearchMode, self.isEffectOverlay = false, false
        local ok, err = pcall(updateOverlay, self)
        self.isSearchMode, self.isEffectOverlay = searching, effect
        if not ok then error(err) end
    end
    ISSearchManager.viewpointWrapped = true
end

local function wrap()
    wrapIcons()
    wrapOverlay()
end

Events.OnGameStart.Add(wrap)
