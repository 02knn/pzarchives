





require "Viewpoint_InvStyle"
require "Viewpoint_InvView"
require "Viewpoint_InvBody"

ViewpointInvTabProtection = {}
local T = ViewpointInvTabProtection
T.__index = T
local S = ViewpointInvStyle
local V = ViewpointInvView
local B = ViewpointInvBody

local PLAYER = 0

local SHAPE_ALPHA, LIT_ALPHA = 0.8, 1.0

local DEFENCES = {
    { bite = true, bullet = false, key = "IGUI_health_Bite" },
    { bite = false, bullet = false, key = "IGUI_health_Scratch" },
    { bite = false, bullet = true, key = "IGUI_health_Bullet" },
}


local function scheme()
    local bad, good = getCore():getBadHighlitedColor(), getCore():getGoodHighlitedColor()
    return { { 0, bad:getR(), bad:getG(), bad:getB() }, { 100, good:getR(), good:getG(), good:getB() } }
end

function T.new()
    return setmetatable({ hits = {} }, T)
end



function T:layout(area, m)
    self.area, self.m = area, m
    local tm = getTextManager()
    local inner = { x = area.x + m.pad * 2, y = area.y + m.pad * 2, w = area.w - m.pad * 4, h = area.h - m.pad * 4 }
    local s = B.fit(inner.w * 0.42, inner.h)
    self.scale = s
    self.origin = { x = inner.x, y = inner.y }
    local x = inner.x + math.ceil(B.W * s) + m.pad * 3
    local medium = tm:getFontHeight(UIFont.Medium)
    local row = math.min(medium + m.pad, math.floor((inner.h - m.header - m.pad) / (B.LAST + 1)))
    self.font = row >= medium + 2 and UIFont.Medium or UIFont.Small
    self.row = row
    self.content = math.max(math.ceil(B.H * s), m.header + m.pad + (B.LAST + 1) * row)
    local column = tm:MeasureStringX(self.font, "100%")
    for _, d in ipairs(DEFENCES) do column = math.max(column, tm:MeasureStringX(UIFont.Small, getText(d.key))) end
    self.column = column + m.pad * 2
    self.table = { x = x, y = inner.y, w = inner.x + inner.w - x, h = inner.h }
end


local function defences(player)
    local all = {}
    for i = 0, B.LAST do
        local values = {}
        for k, d in ipairs(DEFENCES) do
            values[k] = math.floor(player:getBodyPartClothingDefense(i, d.bite, d.bullet) + 0.5)
        end
        all[i] = values
    end
    return all
end

function T:figure(ui, player, values, colours, lit)
    local f = B.textures(player:isFemale())
    local o, s, x, y = ui.javaObject, self.scale, self.origin.x, self.origin.y
    B.body(o, f, x, y, s)
    local function tint(i)
        local v = math.min(100, values[i][1] + values[i][2])
        return V.blend(colours, v), i == lit and LIT_ALPHA or SHAPE_ALPHA
    end
    local function add(hx, hy, hw, hh, i)
        V.addHit(self, hx, hy, hw, hh, { kind = "zone", id = i, label = B.name(i) })
    end
    B.shapes(o, f, x, y, s, tint, add)
    B.outline(o, f, x, y, s)
end

function T:rows(ui, values, colours, lit)
    local m, r = self.m, self.table
    local cx = r.x + r.w - self.column * #DEFENCES
    S.componentHeader(ui, r.x, r.y, r.w, m.header, false)
    S.text(ui, S.caps(getText("IGUI_health_Part")), r.x + m.pad, r.y + m.pad, S.muted)
    for k, d in ipairs(DEFENCES) do
        local x = cx + (k - 1) * self.column + self.column - m.pad
        S.textRight(ui, S.caps(getText(d.key)), x, r.y + m.pad, S.muted)
    end
    local y = r.y + m.header + m.pad
    local textY = math.floor((self.row - getTextManager():getFontHeight(self.font)) / 2)
    for i = 0, B.LAST do
        if i == lit then S.rowHover(ui, r.x, y, r.w, self.row) end
        S.text(ui, S.fit(B.name(i), cx - r.x - m.pad * 2, self.font), r.x + m.pad, y + textY, S.bright, nil, self.font)
        for k = 1, #DEFENCES do
            local v = values[i][k]
            local x = cx + (k - 1) * self.column + self.column - m.pad
            S.textRight(ui, v .. "%", x, y + textY, V.blend(colours, v), nil, self.font)
        end
        V.addHit(self, r.x, y, r.w, self.row, { kind = "zone", id = i })
        y = y + self.row
    end
end


function T:render(ui, view)
    local m = self.m
    self.hits = {}
    if not m then return end
    V.panel(ui, self, self.content)
    local player = getSpecificPlayer(PLAYER)
    if not player then return end
    local values, colours = defences(player), scheme()
    local lit = view.hover and view.hover.kind == "zone" and view.hover.id or nil
    self:figure(ui, player, values, colours, lit)
    self:rows(ui, values, colours, lit)
end

function T:hit(mx, my)
    return V.hit(self, mx, my)
end
