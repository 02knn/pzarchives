






require "Viewpoint_InvStyle"
require "Viewpoint_InvView"
require "Viewpoint_InvBody"

ViewpointInvTabTemperature = {}
local T = ViewpointInvTabTemperature
T.__index = T
local S = ViewpointInvStyle
local V = ViewpointInvView
local B = ViewpointInvBody

local PLAYER = 0

local SHAPE_ALPHA, LIT_ALPHA, UNLIT_ALPHA = 0.8, 1.0, 0.25

local DARK = 0.75
local BLACK = { 0, 0, 0, 1 }

local CHOSEN = { 1.0, 0.78, 0.0, 1.0 }

local heat = getTexture("media/ui/BodyInsulation/heatbar_horz")
local blues = getTexture("media/ui/BodyInsulation/heatbar_horz_blues")
local glow = getTexture("media/ui/BodyInsulation/gradient_highlight")


local HEAT = {
    { 0.0, 29 / 255, 34 / 255, 237 / 255 }, { 0.25, 0, 1, 234 / 255 }, { 0.5, 84 / 255, 1, 55 / 255 },
    { 0.75, 1, 246 / 255, 0 }, { 1.0, 1, 0, 0 },
}
local WET = { { 0.0, 84 / 255, 1, 55 / 255 }, { 0.5, 0, 1, 234 / 255 }, { 1.0, 29 / 255, 34 / 255, 237 / 255 } }



local function newView(title, low, mid, high, getter, wet, value)
    return { title = title, low = low, mid = mid, high = high, getter = getter, ui = getter .. "UI",
        texture = wet and blues or heat, scheme = wet and WET or HEAT, value = value }
end

local VIEWS = {
    default = {
        newView("IGUI_Temp_SkinTemperature", "IGUI_Temp_Cold", "IGUI_Temp_Normal", "IGUI_Temp_Hot", "getSkinCelcius"),
        newView("IGUI_Temp_BodyResponse", "IGUI_Temp_FightCold", "IGUI_Temp_Normal", "IGUI_Temp_FightHot",
            "getBodyResponse"),
        newView("IGUI_Temp_Insulation", "IGUI_Temp_Low", "IGUI_Temp_Med", "IGUI_Temp_High", "getInsulation", false,
            true),
    },
    advanced = {
        newView("IGUI_Temp_SkinTemperature", "IGUI_Temp_Cold", "IGUI_Temp_Normal", "IGUI_Temp_Hot", "getSkinCelcius"),
        newView("IGUI_Temp_BloodVessels", "IGUI_Temp_Vasoconstriction", "IGUI_Temp_Normal", "IGUI_Temp_Vasodilation",
            "getPrimaryDelta"),
        newView("IGUI_Temp_ShiverPerspiration", "IGUI_Temp_Shivering", "IGUI_Temp_Normal", "IGUI_Temp_Perspiring",
            "getSecondaryDelta"),
        newView("IGUI_Temp_BodyWetness", "IGUI_Temp_Dry", nil, "IGUI_Temp_Soaked", "getBodyWetness", true),
        newView("IGUI_Temp_ClothingWetness", "IGUI_Temp_Dry", nil, "IGUI_Temp_Soaked", "getClothingWetness", true),
        newView("IGUI_Temp_Insulation", "IGUI_Temp_Low", "IGUI_Temp_Med", "IGUI_Temp_High", "getInsulation", false,
            true),
        newView("IGUI_Temp_WindResistance", "IGUI_Temp_Low", "IGUI_Temp_Med", "IGUI_Temp_High", "getWindresist", false,
            true),
    },
}

local function thermoregulator(player)
    return player:getBodyDamage():getThermoregulator()
end


local function gradient(ui, tex, x, y, w, h, value)
    if tex then ui.javaObject:DrawTextureScaledColor(tex, x, y, w, h, 1, 1, 1, 1) end
    if value then
        local at = x + math.max(3, math.min(w - 3, value * w))
        local radius = h * 2
        if at - radius > x then S.rect(ui, x, y, at - radius - x, h, BLACK, DARK) end
        if at + radius < x + w then S.rect(ui, at + radius, y, x + w - at - radius, h, BLACK, DARK) end
        if glow then ui.javaObject:DrawTextureScaledColor(glow, at - radius, y, radius * 2, h, 0, 0, 0, DARK) end
    end
    S.edge(ui, x, y, w, h, S.panelEdge)
end


local function words(ui, m, x, y, w, low, mid, high)
    if low then S.text(ui, getText(low), x, y, S.dim) end
    if mid then S.textCentre(ui, getText(mid), x + math.floor(w / 2), y, S.dim) end
    if high then S.textRight(ui, getText(high), x + w, y, S.dim) end
end

function T.new()
    return setmetatable({ hits = {}, chosen = 1, advanced = false }, T)
end

function T:layout(area, m)
    self.area, self.m = area, m
    local inner = { x = area.x + m.pad * 2, y = area.y + m.pad * 2, w = area.w - m.pad * 4, h = area.h - m.pad * 4 }
    local s = B.fit(inner.w * 0.42, inner.h)
    self.scale = s
    self.origin = { x = inner.x, y = inner.y }
    local x = inner.x + math.ceil(B.W * s) + m.pad * 3
    self.column = { x = x, y = inner.y, w = inner.x + inner.w - x, h = inner.h }
    self.medium = getTextManager():getFontHeight(UIFont.Medium)
    self.barH = m.bar * 3
end

function T:views()
    return self.advanced and VIEWS.advanced or VIEWS.default
end


function T:figure(ui, player, thermos, lit)
    local f = B.textures(player:isFemale())
    local o, s, x, y = ui.javaObject, self.scale, self.origin.x, self.origin.y
    local chosen = self:views()[self.chosen]
    B.body(o, f, x, y, s)
    local function tint(i)
        local node = thermos:getNodeForType(BodyPartType.FromIndex(i))
        if not node then return nil end
        local alpha = lit == nil and SHAPE_ALPHA or (i == lit and LIT_ALPHA or UNLIT_ALPHA)
        return V.blend(chosen.scheme, node[chosen.ui](node)), alpha
    end
    local function add(hx, hy, hw, hh, i)
        V.addHit(self, hx, hy, hw, hh, { kind = "zone", id = i, label = B.name(i), view = self })
    end
    B.shapes(o, f, x, y, s, tint, add)
    B.outline(o, f, x, y, s)
end


function T:gauge(ui, x, y, w, title, value, low, mid, high)
    local m = self.m
    S.text(ui, S.caps(getText(title)), x, y, S.muted)
    y = y + m.font + 2
    gradient(ui, heat, x, y, w, self.barH, value)
    words(ui, m, x, y + self.barH + 1, w, low, mid, high)
    return m.font * 2 + self.barH + m.pad + 3
end



function T:viewLine(ui, x, y, w, index, v, node, hover)
    local m = self.m
    local h = self.medium + self.barH + m.pad * 2
    if V.over(hover, "view", index) then S.rowHover(ui, x, y, w, h) end
    local colour = index == self.chosen and CHOSEN or S.bright
    S.text(ui, S.fit(getText(v.title), w - m.pad * 2, UIFont.Medium), x + m.pad, y + 2, colour, nil, UIFont.Medium)
    if node and (v.value or isDebugEnabled()) then
        local raw = node[v.getter](node)
        S.textRight(ui, string.format("%.2f", raw), x + w - m.pad, y + 2, S.muted, nil, UIFont.Medium)
    end
    local bx, by, bw = x + m.pad, y + self.medium + m.pad, w - m.pad * 2
    gradient(ui, v.texture, bx, by, bw, self.barH, node and node[v.ui](node) or nil)
    if not node then S.rect(ui, bx, by, bw, self.barH, BLACK, DARK) end
    V.addHit(self, x, y, w, h, { kind = "view", id = index, view = self })
    return h
end



function T:readings(ui, thermos, lit, hover)
    local m, c = self.m, self.column
    local x, y, w = c.x, c.y, c.w
    y = y + self:gauge(ui, x, y, w, "IGUI_Temp_CoreTemp", thermos:getCoreTemperatureUI(), "IGUI_Temp_Cold",
        "IGUI_Temp_Normal", "IGUI_Temp_Hot")
    y = y + self:gauge(ui, x, y, w, "IGUI_Temp_BodyHeat", thermos:getHeatGenerationUI(), "IGUI_Temp_Low",
        "IGUI_Temp_Normal", "IGUI_Temp_High")
    V.header(ui, m, x, y, w, lit and B.name(lit) or getText("IGUI_XP_ClothingIns"))
    y = y + m.header + 2
    local node = lit and thermos:getNodeForType(BodyPartType.FromIndex(lit)) or nil
    for index, v in ipairs(self:views()) do y = y + self:viewLine(ui, x, y, w, index, v, node, hover) end
    local chosen = self:views()[self.chosen]
    local buttonH = m.font + m.pad
    local legendH = m.pad + self.barH * 2 + 1 + m.font + m.pad * 2
    if y + legendH + buttonH <= c.y + c.h then
        gradient(ui, chosen.texture, x, y + m.pad, w, self.barH * 2, nil)
        words(ui, m, x, y + m.pad + self.barH * 2 + 1, w, chosen.low, chosen.mid, chosen.high)
        y = y + legendH
    end
    local label = getText(self.advanced and "IGUI_Temp_DefView" or "IGUI_Temp_AdvView")
    V.button(ui, self, { x = x, y = y, w = w, h = buttonH }, label, { kind = "advanced", id = 1, view = self }, hover)
    return y + buttonH - c.y
end


function T:render(ui, view)
    local m = self.m
    self.hits = {}
    if not m then return end
    V.panel(ui, self, self.content)
    local player = getSpecificPlayer(PLAYER)
    local thermos = player and thermoregulator(player)
    if not thermos then return end
    local hover = view.hover
    local lit = hover and hover.kind == "zone" and hover.id or self.held
    self:figure(ui, player, thermos, lit)
    self.content = math.max(math.ceil(B.H * self.scale), self:readings(ui, thermos, lit, hover))
end

function T:hit(mx, my)
    return V.hit(self, mx, my)
end


function T:click(h)
    if h.kind == "zone" then
        self.held = self.held ~= h.id and h.id or nil
    elseif h.kind == "view" then
        self.chosen = h.id
    elseif h.kind == "advanced" then
        self.advanced = not self.advanced
        self.chosen = 1
    end
end
