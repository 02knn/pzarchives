




require "Viewpoint_InvStyle"

ViewpointInvBar = {}
local B = ViewpointInvBar
B.__index = B
local S = ViewpointInvStyle

local PLAYER = 0

local CONTROLS = {
    "Drag: move    Shift+drag: split    Ctrl+click: across",
    "Alt+click: equip    Double-click: use    Right-click: actions",
}


local glyphs = {}

local function glyph(button)
    local pads = Viewpoint and Viewpoint.Pads
    local path = pads and pads.glyph(button) or ""
    if path == "" then return nil end
    glyphs[path] = glyphs[path] or getTexture(path)
    return glyphs[path]
end

function B.new()
    return setmetatable({ hits = {}, x = 0, y = 0, w = 0, h = 0 }, B)
end


function B:layout(x, y, w, h, m, side)
    self.x, self.y, self.w, self.h, self.m, self.side = x, y, w, h, m, side
end

local function hit(self, x, y, w, h, target)
    table.insert(self.hits, { x = x, y = y, w = w, h = h, target = target })
end



function B:prompts(ui, rows)
    local m = self.m
    local size = math.floor((self.h - m.pad * 2) / #rows)
    local right = self.x + self.side - m.pad
    for i, row in ipairs(rows) do
        local x, y = self.x + m.pad, self.y + m.pad + (i - 1) * size
        for _, prompt in ipairs(row) do
            local wx = x + #prompt[1] * size + m.gap
            local width = getTextManager():MeasureStringX(UIFont.Small, prompt[2])
            if wx + width > right then break end
            for j, button in ipairs(prompt[1]) do S.icon(ui, glyph(button), x + (j - 1) * size, y, size) end
            S.text(ui, prompt[2], wx, y + math.floor((size - m.font) / 2), S.muted)
            x = wx + width + m.pad * 2
        end
    end
end



function B:render(ui, view)
    local m = self.m
    self.hits = {}
    local over = view.hover
    if view.drag and over and over.kind == "hotbar" then
        S.edge(ui, over.x, over.y, over.w, over.h, view.drag.attaches[over.index] and S.drop or S.refuse)
    end
    if not view.padMode and view.config.controls == false then return end
    S.box(ui, self.x, self.y, self.side, self.h)
    if view.padMode then
        self:prompts(ui, view:padPrompts())
    else
        local ty = self.y + math.floor((self.h - #CONTROLS * m.font) / 2)
        for i, line in ipairs(CONTROLS) do
            S.text(ui, S.fit(line, self.side - m.pad * 2), self.x + m.pad, ty + (i - 1) * m.font, S.muted)
        end
    end
    hit(self, self.x, self.y, self.side, self.h, { kind = "bar" })
end


function B:hit(mx, my)
    for i = #self.hits, 1, -1 do
        local h = self.hits[i]
        if mx >= h.x and mx < h.x + h.w and my >= h.y and my < h.y + h.h then return h.target end
    end
    return nil
end



function B.hotbarAt(ui, mx, my)
    local hotbar = getPlayerHotbar(PLAYER)
    if not hotbar or not hotbar:isVisible() then return nil end
    local ox, oy = hotbar:getAbsoluteX() - ui:getAbsoluteX(), hotbar:getAbsoluteY() - ui:getAbsoluteY()
    local i = hotbar:getSlotIndexAt(mx - ox, my - oy)
    local slot = hotbar.availableSlot[i]
    if not slot then return nil end
    return { kind = "hotbar", index = i, item = hotbar.attachedItems[i], slot = slot,
             x = ox + hotbar.margins + 1 + (i - 1) * (hotbar.slotWidth + hotbar.slotPad),
             y = oy + hotbar.margins + 1, w = hotbar.slotWidth, h = hotbar.slotHeight }
end


function B.slotName(slot)
    return getTextOrNull("IGUI_HotbarAttachment_" .. slot.slotType) or slot.name
end
