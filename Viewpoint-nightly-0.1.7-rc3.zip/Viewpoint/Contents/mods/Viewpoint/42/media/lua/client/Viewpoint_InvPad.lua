












require "Viewpoint_InvScreen"
require "Viewpoint_InvActions"

ViewpointInvPad = ViewpointInvPad or {}

local Screen = ViewpointInvScreen
local A = ViewpointInvActions
local D = ViewpointInvData

local PLAYER = 0


local SKIPPED = { takeAll = true, equipment = true, hands = true, panel = true, section = true, stackArrow = true,
    slotDot = true, slotStep = true, fold = true, footer = true }

local ALONG = 13

local LAST_ROW = { { { "Y" }, "Close" }, { { "LB", "RB" }, "Tabs" } }


function Screen.onPad()
    return JoypadState.players[PLAYER + 1] ~= nil
end

local function extra(list, r, target)
    if r then table.insert(list, { x = r.x, y = r.y, w = r.w, h = r.h, target = target }) end
end




function Screen:padSources()
    local extras = {}
    for _, b in ipairs(self.tabs.buttons) do extra(extras, b, { kind = "tab", id = b.tab.id }) end
    for _, grid in ipairs({ self.nearby, self.inventory }) do
        extra(extras, grid.filterRect, { kind = "filter", grid = grid })
        extra(extras, grid.orderRect, { kind = "order", grid = grid })
        extra(extras, grid.gridRect, { kind = "layout", grid = grid, list = false, view = grid })
        extra(extras, grid.listRect, { kind = "layout", grid = grid, list = true, view = grid })
    end
    if self.details then extra(extras, self.details.crossRect, { kind = "detailsClose" }) end
    local sources = {
        { hits = self.nearby.hits, grid = self.nearby },
        { hits = self.inventory.hits, grid = self.inventory },
        { hits = self.gear.hits },
        { hits = extras },
    }
    local shown = self.tabs:shown()
    if shown then
        table.insert(sources, { hits = shown.hits, view = shown })
    elseif not self.details then
        table.insert(sources, { hits = self.hands.hits })
    end
    return sources
end


local function same(a, b)
    if a.kind ~= b.kind then return false end
    local k = a.kind
    if k == "tile" then return a.section.container == b.section.container and a.stack.key == b.stack.key end
    if k == "header" then return a.section.container == b.section.container end
    if k == "order" or k == "filter" or k == "clearSelected" or k == "sendSelected" then return a.grid == b.grid end
    if k == "layout" then return a.grid == b.grid and a.list == b.list end
    if k == "slot" then return a.slot == b.slot end
    if k == "hand" then return a.primary == b.primary end
    return a.id == b.id and a.item == b.item and a.part == b.part and a.perk == b.perk and a.category == b.category
end

local function distance(a, b)
    local dx, dy = a.x + a.w / 2 - b.x - b.w / 2, a.y + a.h / 2 - b.y - b.h / 2
    return dx * dx + dy * dy
end


local function nearest(sources, was, takes)
    local best, from, least
    for _, source in ipairs(sources) do
        for _, h in ipairs(source.hits) do
            if not SKIPPED[h.target.kind] and takes(h.target) then
                local d = was and distance(h, was) or 0
                if not best or d < least then best, from, least = h, source, d end
            end
        end
    end
    return best, from
end

local function any()
    return true
end




function Screen:padFind(sources)
    local was, at = self.padRect, self.padAt
    local h, source
    if at then h, source = nearest(sources, was, function(t) return same(t, at) end) end
    if not h and was then h, source = nearest(sources, was, any) end
    if not h then h, source = nearest(sources, nil, function(t) return t.kind == "tile" end) end
    if not h then h, source = nearest(sources, nil, any) end
    return h, source
end



local function reveal(m, h, source)
    local list = source.grid and source.grid.body or source.view and source.view.scrolled
    if not list or h.x < list.x or h.x + h.w > list.x + list.w + 1 then return end
    local room = math.max(0, math.min(m.tile + m.gap, math.floor((list.h - h.h) / 2)))
    local over, under = list.y + room - h.y, h.y + h.h - (list.y + list.h - room)
    local by = over > 0 and -over or math.max(0, under)
    if by == 0 then return end
    if source.grid then
        source.grid:scrollBy(by)
    else
        ViewpointInvView.wheel(source.view, by)
    end
end



function Screen:padFrame()
    local focus = getJoypadFocus(PLAYER)
    if focus == nil or (focus ~= self and not focus:isReallyVisible()) then setJoypadFocus(PLAYER, self) end
    local h, source = self:padFind(self:padSources())
    self.padRect, self.padAt = h, h and h.target
    if h then reveal(self.m, h, source) end
end


function Screen:padRelease()
    local focus = getJoypadFocus(PLAYER)
    if focus ~= nil and (focus == self or not focus:isReallyVisible()) then setJoypadFocus(PLAYER, nil) end
end



local function reach(a, b, dx, dy)
    if dx > 0 then return b.x - a.x - a.w, b.x + b.w - a.x - a.w, b.x - a.x end
    if dx < 0 then return a.x - b.x - b.w, a.x - b.x, a.x + a.w - b.x - b.w end
    if dy > 0 then return b.y - a.y - a.h, b.y + b.h - a.y - a.h, b.y - a.y end
    return a.y - b.y - b.h, a.y - b.y, a.y + a.h - b.y - b.h
end


local function ahead(a, b, dx, dy)
    local near, far, start = reach(a, b, dx, dy)
    return far > 0 and (start > 0 or near >= 0)
end


local function inBeam(a, b, dx)
    if dx ~= 0 then return b.y + b.h > a.y and b.y < a.y + a.h end
    return b.x + b.w > a.x and b.x < a.x + a.w
end



local function beamBeats(a, r1, r2, dx, dy)
    if inBeam(a, r2, dx) or not inBeam(a, r1, dx) then return false end
    local near2, far2 = reach(a, r2, dx, dy)
    if near2 < 0 or dx ~= 0 then return true end
    return math.max(0, (reach(a, r1, dx, dy))) < math.max(1, far2)
end


local function score(a, b, dx, dy, ax)
    local along = math.max(0, (reach(a, b, dx, dy)))
    local across = dx ~= 0 and math.abs(a.y + a.h / 2 - b.y - b.h / 2) or math.abs(ax - b.x - b.w / 2)
    return ALONG * along * along + across * across
end

local function better(a, r1, r2, dx, dy, ax)
    if r2 == nil or beamBeats(a, r1, r2, dx, dy) then return true end
    if beamBeats(a, r2, r1, dx, dy) then return false end
    return score(a, r1, dx, dy, ax) < score(a, r2, dx, dy, ax)
end



function Screen:padMove(dx, dy)
    local a = self.padRect
    if not a then return end
    local wide = self.m.tile * 3
    local ax = (a.w > wide and self.padAnchor) or a.x + a.w / 2
    local best
    for _, source in ipairs(self:padSources()) do
        for _, h in ipairs(source.hits) do
            if h ~= a and not SKIPPED[h.target.kind] and ahead(a, h, dx, dy) and better(a, h, best, dx, dy, ax) then
                best = h
            end
        end
    end
    if not best then return end
    self.padRect, self.padAt = best, best.target
    if best.w <= wide then self.padAnchor = best.x + best.w / 2 end
end



function Screen:menuToPad()
    local menu = getPlayerContextMenu(PLAYER)
    if menu and menu:getIsVisible() and menu.numOptions > 1 then
        menu.origin, menu.mouseOver = self, 1
        setJoypadFocus(PLAYER, menu)
    end
end


function Screen:padChoose(t)
    local chosen = self.selected[t.section.container] or {}
    self.selected[t.section.container] = chosen
    chosen[t.stack.key] = (not chosen[t.stack.key]) or nil
end


function Screen:padSplit(t)
    local mine = t.section.mine
    local dest = mine and self.across or (self.into or self.player:getInventory())
    if not dest then return end
    if not mine then self.across = t.section.container end
    local items, most = A.fitting(D.items({ t.stack }), dest)
    local move = function(list) A.move(list, dest) end
    if most == 1 then return move({ items[1] }) end
    if most > 1 then
        local r = self.padRect or { x = self.width / 2, y = self.height / 2, w = 0, h = 0 }
        local x, y = r.x + r.w / 2, r.y + r.h / 2
        self.split = ViewpointInvSplit.new(items, most, move, x, y, self.m, self.width, self.height)
    end
end



local function tileOptions(self, menu, t)
    local chosen = self.selected[t.section.container]
    menu:addOption((chosen and chosen[t.stack.key]) and "Unchoose" or "Choose", self, Screen.padChoose, t)
    if t.stack.count > 1 and (not t.section.mine or self.across) then
        menu:addOption("Split across", self, Screen.padSplit, t)
    end
end



function Screen:padAccept(t, r)
    local k = t.kind
    if k == "slot" and #t.items > 1 then
        self:wornMenu(t, r.x + r.w, r.y, true)
    elseif k == "tile" or ((k == "slot" or k == "hand") and t.item) then
        local menu = self:itemMenu(self:itemsOf(t), r.x + r.w, r.y)
        if menu and k == "tile" then tileOptions(self, menu, t) end
    elseif k == "part" then
        self.tabs:menu(t.part, r.x + r.w, r.y)
    elseif k == "header" and t.section.mine then
        if not t.section.equipped then self:chooseInto(t.section.container) end
    elseif k == "header" then
        self.across = t.section.container
    else
        self:click(t)
    end
    self:menuToPad()
end



function Screen:padSend(t)
    local k = t.kind
    if k == "tile" then
        self:send(t)
    elseif (k == "slot" or k == "hand") and t.item then
        A.unequip(t.item)
    elseif k == "order" then
        t.grid:reverseOrder()
    elseif k == "header" then
        for _, h in ipairs(self.nearby.hits) do
            local all = h.target
            if all.kind == "takeAll" and all.section.container == t.section.container then return self:click(all) end
        end
    end
end



function Screen:padCancelWords(t)
    if isPlayerDoingActionThatCanBeCancelled(self.player) then return "Cancel action" end
    if self.details then return "Close details" end
    if t and t.kind == "header" then return t.section.folded and "Unfold" or "Fold" end
    return nil
end

function Screen:padCancel(t)
    if isPlayerDoingActionThatCanBeCancelled(self.player) then
        stopDoingActionThatCanBeCancelled(self.player)
    elseif self.details then
        self:closeDetails()
    elseif t and t.kind == "header" then
        t.section.folded = not t.section.folded
    end
end



function Screen:padPrompts()
    if self.split then return { { { { "A" }, "Ok" }, { { "B" }, "Cancel" } }, LAST_ROW } end
    if self.filterMenu then return { { { { "A" }, "Tick" }, { { "B" }, "Close" } }, LAST_ROW } end
    local t = self.padAt
    local k = t and t.kind
    local row = {}
    if k == "tile" or k == "part" or ((k == "slot" or k == "hand") and t.item) then
        table.insert(row, { { "A" }, "Actions" })
    elseif k == "header" then
        table.insert(row, { { "A" }, "Choose" })
    elseif t then
        table.insert(row, { { "A" }, "Select" })
    end
    if k == "tile" and (not t.section.mine or self.across) then
        table.insert(row, { { "X" }, "Across" })
    elseif (k == "slot" or k == "hand") and t.item then
        table.insert(row, { { "X" }, "Take off" })
    elseif k == "order" then
        table.insert(row, { { "X" }, "Reverse" })
    elseif k == "header" and not t.section.mine and not t.section.locked and #t.section.stacks > 0 then
        table.insert(row, { { "X" }, getText("IGUI_invpage_Loot_all") })
    end
    local cancel = self:padCancelWords(t)
    if cancel then table.insert(row, { { "B" }, cancel }) end
    return { row, LAST_ROW }
end

function Screen:onJoypadDown(button, joypadData)
    if not self.up then return end
    local t = self.padAt
    if self.split then
        if button == Joypad.AButton then self.split:confirm() end
        if button == Joypad.AButton or button == Joypad.BButton then self.split = nil end
    elseif self.filterMenu then
        if button == Joypad.AButton then self.filterMenu:choose(self.filterMenu.at) end
        if button == Joypad.BButton then self.filterMenu = nil end
    elseif button == Joypad.AButton and t then
        self:padAccept(t, self.padRect)
    elseif button == Joypad.XButton and t then
        self:padSend(t)
    elseif button == Joypad.BButton then
        self:padCancel(t)
    elseif button == Joypad.YButton then
        ViewpointInventory.close()
    elseif button == Joypad.LBumper or button == Joypad.RBumper then
        local id = self.tabs:along(button == Joypad.LBumper and -1 or 1)
        self:selectTab(id)
        self.padAt = { kind = "tab", id = id }
    end
end


function Screen:padDirection(dx, dy)
    if not self.up then return end
    if self.split then
        self.split:set(self.split.n + dx)
    elseif self.filterMenu then
        self.filterMenu:step(dy)
    else
        self:padMove(dx, dy)
    end
end

function Screen:onJoypadDirUp(joypadData)
    self:padDirection(0, -1)
end

function Screen:onJoypadDirDown(joypadData)
    self:padDirection(0, 1)
end

function Screen:onJoypadDirLeft(joypadData)
    self:padDirection(-1, 0)
end

function Screen:onJoypadDirRight(joypadData)
    self:padDirection(1, 0)
end



local function wrapPrompts()
    for _, name in ipairs({ "cmdShowInventory", "cmdShowLoot" }) do
        local show = ISButtonPrompt[name]
        ISButtonPrompt[name] = function(prompt, ...)
            local loot = Viewpoint and Viewpoint.Loot
            if prompt.player == PLAYER and loot and loot.openScreen(nil) then return end
            return show(prompt, ...)
        end
    end
end



local function wrapWheel()
    local command = ISBackButtonWheel.onCommand
    ISBackButtonWheel.onCommand = function(wheel, name, ...)
        local loot = Viewpoint and Viewpoint.Loot
        if name == "PlayerInfo" and wheel.playerNum == PLAYER and loot and loot.openScreen("info") then
            setJoypadFocus(wheel.playerNum, nil)
            return
        end
        return command(wheel, name, ...)
    end
end

local function install()
    if ViewpointInvPad.installed or not ISButtonPrompt or not ISBackButtonWheel then return end
    ViewpointInvPad.installed = true
    wrapPrompts()
    wrapWheel()
end

install()
Events.OnGameBoot.Add(install)
