








ViewpointBuild = ViewpointBuild or {}



local GHOSTS = { RenderGhostTile = { 1, 1, 1, 0.6 }, RenderGhostTileRed = { 0.65, 0.2, 0.2, 0.6 },
                 RenderGhostTileColor = { 1, 1, 1, 0.6 } }

local QUIET = { "renderIsoCircle", "renderIsoLine" }


local FACE = { 1, 0, 3, 2 }

local EDGE_GAP = 0.05


local point = nil
local driving = false
local shown = {}
local wrapped = {}


local ghosts, items = {}, {}

local function viewOn()
    return Viewpoint and Viewpoint.Loot and Viewpoint.Loot.viewOn()
end


function ViewpointBuild.barricade(cursor)
    local script = cursor.objectInfo and cursor.objectInfo:getScript()
    local name = script and script:getName()
    return name ~= nil and luautils.stringStarts(name, "Barricade")
end



local function onEdge(cursor)
    if cursor.Type == "ISMoveableCursor" then return false end
    return cursor.isWallLike == true or cursor.needToBeAgainstWall == true or ViewpointBuild.barricade(cursor)
end



local function hasFace(cursor, n)
    if cursor.objectInfo then return cursor.objectInfo:getFace(FACE[n]) ~= nil end
    if n == 3 then return cursor.eastSprite ~= nil end
    if n == 4 then return cursor.southSprite ~= nil end
    return true
end



local function snap(cursor, edge)
    if hasFace(cursor, edge) then return edge, 0, 0 end
    if edge == 4 then return 2, 0, 1 end
    if edge == 3 then return 1, 1, 0 end
    return edge, 0, 0
end


local function standsOn(cursor)
    if not onEdge(cursor) then return 0 end
    local n = cursor.nSprite or 0
    if n == 4 and not hasFace(cursor, 4) then return 2 end
    if n == 3 and not hasFace(cursor, 3) then return 1 end
    return n
end






function ViewpointBuild.place(cursor, x, y, z, px, py, edge)
    driving = true
    ghosts, items = {}, {}
    point = point or {}
    point.x, point.y = px, py
    if cursor.joypadPositionX ~= nil then


        cursor.joypadPositionX = math.max(EDGE_GAP, math.min(1 - EDGE_GAP, px - x))
        cursor.joypadPositionY = math.max(EDGE_GAP, math.min(1 - EDGE_GAP, py - y))
    end
    if onEdge(cursor) then
        local key = x .. "," .. y .. "," .. edge
        if not cursor.isLeftDown and cursor.viewpointEdge ~= key then
            local n, dx, dy = snap(cursor, edge)
            cursor.viewpointEdge, cursor.viewpointDx, cursor.viewpointDy = key, dx, dy
            cursor.nSprite = n
        end
        x = x + (cursor.viewpointDx or 0)
        y = y + (cursor.viewpointDy or 0)
    else
        cursor.viewpointEdge = nil
    end
    shown.x, shown.y = x, y
    return shown
end




function ViewpointBuild.done(cursor)
    driving, point = false, nil
    local sq = cursor.square
    if sq then shown.x, shown.y = sq:getX(), sq:getY() end
    shown.valid = cursor.canBeBuild == true
    shown.edge = standsOn(cursor)
    shown.ghosts, shown.items = ghosts, items
    return shown
end



function ViewpointBuild.none(cursor)
    driving, point = false, nil
    cursor.canBeBuild = false
    cursor.build = false
end



local function caught(sprite, tint, x, y, z, ...)
    local n = select("#", ...)
    local a1, a2, a3, a4, a5, a6 = ...
    if n >= 6 then
        ghosts[#ghosts + 1] = { sprite, x, y, z, a1, a2, a3, a4, a5, a6 }
    elseif n >= 4 then
        ghosts[#ghosts + 1] = { sprite, x, y, z, 0, 0, a1, a2, a3, a4 }
    else
        ghosts[#ghosts + 1] = { sprite, x, y, z, 0, 0, tint[1], tint[2], tint[3], tint[4] }
    end
end




local function holdGhosts()
    local mt = getmetatable(IsoSprite.new())
    local index = mt and mt.__index
    if type(index) ~= "table" then return false end
    for name, tint in pairs(GHOSTS) do
        local draw = index[name]
        if draw and draw ~= wrapped[name] then
            local held = function(self, ...)
                if not viewOn() then return draw(self, ...) end
                if driving then caught(self, tint, ...) end
            end
            wrapped[name] = held
            index[name] = held
        end
    end
    return true
end




local function itemPreview(f)
    return function(item, sq, x, y, z, degrees)
        if not viewOn() then return f(item, sq, x, y, z, degrees) end
        if driving then items[#items + 1] = { item, sq, x, y, z, degrees } end
    end
end


local function wrap(name, make)
    local f = _G[name]
    if not f or f == wrapped[name] then return end
    local w = make(f)
    wrapped[name] = w
    _G[name] = w
end





local function infoWindowAside()
    local window = ISMoveableInfoWindow
    if not window or window.prerender == wrapped.infoWindow then return end
    local prerender = window.prerender
    wrapped.infoWindow = function(self)
        local at = window.displayPosition
        if not viewOn() or at ~= "cursor" and at ~= "norender" then return prerender(self) end
        window.displayPosition = "left"
        local ok, err = pcall(prerender, self)
        window.displayPosition = at
        if not ok then error(err) end
    end
    window.prerender = wrapped.infoWindow
end






local function placeWalks()
    local cursor = ISPlace3DItemCursor
    if not cursor or cursor.create == wrapped.placeCreate then return end
    local create = cursor.create
    wrapped.placeCreate = function(self, ...)
        if not viewOn() then return create(self, ...) end
        local test = luautils.walkAdjAltTest
        luautils.walkAdjAltTest = function(playerObj, square, altSquare, keepActions)
            return test(playerObj, square, nil, keepActions)
        end
        local ok, err = pcall(create, self, ...)
        luautils.walkAdjAltTest = test
        if not ok then error(err) end
    end
    cursor.create = wrapped.placeCreate
end





local function driveOnly(cursor, isRender, x, y, z, square)
    if viewOn() and not driving then return end
    if getCell():getDrag(cursor.player or 0) ~= cursor then return end
    DoTileBuilding(cursor, isRender, x, y, z, square)
end

local function start()
    local held = holdGhosts()
    for _, name in ipairs(QUIET) do
        wrap(name, function(f) return function(...) if viewOn() then return end return f(...) end end)
    end
    wrap("Render3DItem", itemPreview)
    infoWindowAside()
    placeWalks()
    wrap("screenToIsoX", function(f) return function(...) if point then return point.x end return f(...) end end)
    wrap("screenToIsoY", function(f) return function(...) if point then return point.y end return f(...) end end)
    if DoTileBuilding then
        Events.OnDoTileBuilding2.Remove(DoTileBuilding)
        Events.OnDoTileBuilding2.Remove(driveOnly)
        Events.OnDoTileBuilding2.Add(driveOnly)
    end
    print("[Viewpoint] building in the view: the game's cursors driven by the crosshair"
        .. (held and "" or "; their isometric previews could not be held off"))
end

Events.OnGameStart.Add(start)
