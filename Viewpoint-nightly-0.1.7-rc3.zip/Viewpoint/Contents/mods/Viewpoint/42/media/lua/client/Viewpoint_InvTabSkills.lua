






require "Viewpoint_InvStyle"
require "Viewpoint_InvView"

ViewpointInvTabSkills = {}
local T = ViewpointInvTabSkills
T.__index = T
local S = ViewpointInvStyle
local V = ViewpointInvView

local PLAYER = 0
local LEVELS = 10

local GOLD = { 1.0, 0.89, 0.38 }
local PROGRESS, LOCKED = 0.4, 0.2

local BOOSTS = {
    [0] = { 0.54, 0.54, 0.54, 1 }, [1] = { 0.8, 0.8, 0.8, 1 }, [2] = S.bright, [3] = { 1.0, 0.83, 0.0, 1 },
}

local ARROW_MS = 500

local folded = getTexture("media/ui/inventoryPanes/Button_TreeCollapsed.png")
local unfolded = getTexture("media/ui/inventoryPanes/Button_TreeExpanded.png")
local fill = getTexture("media/ui/SkillPanel/SkillUnit_Fill.png")
local border = getTexture("media/ui/SkillPanel/SkillUnit_Border.png")
local arrow = getTexture("media/ui/ArrowRight.png")
local arrowOff = getTexture("media/ui/ArrowRight_Disabled.png")


local function categories()
    local list, byParent = {}, {}
    for i = 0, PerkFactory.PerkList:size() - 1 do
        local perk = PerkFactory.PerkList:get(i)
        local parent = perk:getParent()
        if parent ~= Perks.None then
            if not byParent[parent] then
                byParent[parent] = { perk = PerkFactory.getPerk(parent), skills = {} }
                table.insert(list, byParent[parent])
            end
            table.insert(byParent[parent].skills, perk)
        end
    end
    table.sort(list, function(a, b)
        local pa, pb = a.perk:isPassiv(), b.perk:isPassiv()
        if pa ~= pb then return pa end
        return not string.sort(a.perk:getName(), b.perk:getName())
    end)
    for _, c in ipairs(list) do
        table.sort(c.skills, function(a, b) return a:getName() < b:getName() end)
    end
    return list
end


local function progress(player, perk)
    local level = player:getPerkLevel(perk:getType())
    local needed = ISSkillProgressBar.getXpForLvl(perk, level)
    local xp = player:getXp():getXP(perk:getType()) - ISSkillProgressBar.getPreviousXpLvl(perk, level)
    return { perk = perk, char = player, level = level, xpForLvl = needed, xp = math.min(xp, needed) }
end


local function note(perk, index)
    local bar = progress(getSpecificPlayer(PLAYER), perk)
    if index < 0 or index >= LEVELS then index = math.min(bar.level, LEVELS - 1) end
    ISSkillProgressBar.updateTooltip(bar, index)
    return bar.message
end

function T.new()
    return setmetatable({ scroll = 0, hits = {}, folded = {} }, T)
end



function T:layout(area, m)
    self.area, self.m = area, m
    self.list = self.list or categories()
    local tm = getTextManager()
    self.row = tm:getFontHeight(UIFont.Medium) + m.pad
    self.box = { x = area.x + m.pad * 2, y = area.y + m.pad * 2, w = area.w - m.pad * 4, h = area.h - m.pad * 4 }
    local names = 0
    for _, c in ipairs(self.list) do
        for _, perk in ipairs(c.skills) do names = math.max(names, tm:MeasureStringX(UIFont.Medium, perk:getName())) end
    end
    self.arrow = math.floor(self.row * 0.6)
    self.nameX = self.arrow * 3 + m.pad * 2
    self.nameW = math.min(names, math.floor(self.box.w * 0.5))
    local room = self.box.w - self.nameX - self.nameW - m.pad * 3
    self.square = math.max(6, math.min(math.floor(self.row * 0.62), math.floor(room / LEVELS * 0.8)))
    self.step = self.square + math.max(2, math.floor(self.square / 4))
end

local function square(o, tex, x, y, size, w, shade)
    o:DrawTextureScaledColor(tex, x, y, w or size, size, shade[1], shade[2], shade[3], 1)
end


function T:squares(ui, x, y, bar)
    local o, size, step = ui.javaObject, self.square, self.step
    for _ = 1, bar.level do
        square(o, fill, x, y, size, nil, GOLD)
        square(o, border, x, y, size, nil, GOLD)
        x = x + step
    end
    if bar.level < LEVELS then
        local f = bar.xpForLvl > 0 and math.max(0, bar.xp / bar.xpForLvl) or 0
        if f >= 1 then
            square(o, fill, x, y, size, nil, GOLD)
            if not bar.perk:isPassiv() then square(o, border, x, y, size, nil, S.bright) end
        else
            square(o, border, x, y, size, nil, { PROGRESS, PROGRESS, PROGRESS })
            if f > 0 then square(o, fill, x, y, size, math.floor(size * f), { PROGRESS, PROGRESS, PROGRESS }) end
        end
        x = x + step
    end
    for _ = bar.level + 2, LEVELS do
        square(o, border, x, y, size, nil, { LOCKED, LOCKED, LOCKED })
        x = x + step
    end
end


function T:arrows(ui, x, y)
    local size = self.arrow
    local lit = math.floor(getTimestampMs() / ARROW_MS) % 4 - 1
    for i = 0, 2 do S.icon(ui, i == lit and arrow or arrowOff, x + i * size, y, size) end
end

function T:skill(ui, player, perk, x, y)
    local m, row = self.m, self.row
    local xp = player:getXp()
    local kind = perk:getType()
    if xp:getMultiplier(kind) > 0 then self:arrows(ui, x, y + math.floor((row - self.arrow) / 2)) end
    local colour = BOOSTS[xp:getPerkBoost(kind)] or S.bright
    local nameX = x + self.nameX
    S.text(ui, S.fit(perk:getName(), self.nameW, UIFont.Medium), nameX, y + math.floor(m.pad / 2), colour, nil,
        UIFont.Medium)
    local sx = nameX + self.nameW + m.pad * 2
    self:squares(ui, sx, y + math.floor((row - self.square) / 2), progress(player, perk))
    return sx
end


function T:header(ui, c, x, y, w, view)
    local m = self.m
    local over = view.hover and view.hover.kind == "category" and view.hover.category == c
    S.componentHeader(ui, x, y, w, m.header, over)
    S.icon(ui, self.folded[c] and folded or unfolded, x + m.pad, y + math.floor((m.header - 12) / 2), 12)
    S.text(ui, S.caps(c.perk:getName()), x + m.pad + 16, y + m.pad, S.bright)
end


function T:render(ui, view)
    local m, a, b = self.m, self.area, self.box
    self.hits = {}
    if not m then return end
    S.box(ui, a.x, a.y, a.w, a.h)
    local player = getSpecificPlayer(PLAYER)
    if not player then return end
    ui:setStencilRect(b.x, b.y, b.w, b.h)
    local y = b.y - self.scroll
    local function shows(top, h) return top + h > b.y and top < b.y + b.h end
    for _, c in ipairs(self.list) do
        if shows(y, m.header) then
            self:header(ui, c, b.x, y, b.w, view)
            V.addClipped(self, b, b.x, y, b.w, m.header, { kind = "category", category = c, view = self })
        end
        y = y + m.header + math.floor(m.pad / 2)
        if not self.folded[c] then
            for _, perk in ipairs(c.skills) do
                if shows(y, self.row) then
                    local sx = self:skill(ui, player, perk, b.x, y)
                    V.addClipped(self, b, b.x, y, b.w, self.row, { kind = "skill", perk = perk, squares = sx })
                end
                y = y + self.row
            end
        end
        y = y + m.pad
    end
    ui:clearStencilRect()
    V.scroll(ui, self, b, y + self.scroll - b.y)
end



function T:hit(mx, my)
    local t = V.hit(self, mx, my)
    if t and t.kind == "skill" then
        local index = mx >= t.squares and math.floor((mx - t.squares) / self.step) or -1
        t.note = note(t.perk, index)
    end
    return t
end

function T:wheel(mx, my, del)
    if not V.inside(self.box, mx, my) then return false end
    V.wheel(self, del * self.row * 2)
    return true
end

function T:click(h)
    if h.kind == "category" then self.folded[h.category] = not self.folded[h.category] end
end
