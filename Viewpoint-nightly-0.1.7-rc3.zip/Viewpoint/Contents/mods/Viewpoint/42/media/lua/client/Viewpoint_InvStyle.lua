














ViewpointInvStyle = {}
local S = ViewpointInvStyle


local VANILLA = {
    panelEdge = { 0.4, 0.4, 0.4, 1.0 },
    lightEdge = { 0.7, 0.7, 0.7, 1.0 },
    header = { 0.1, 0.1, 0.1, 1.0 },
    headerHover = { 0.3, 0.3, 0.3, 1.0 },
    buttonFill = { 0.0, 0.0, 0.0, 1.0 },
    field = { 0.0, 0.0, 0.0, 0.5 },
    tile = { 0.1, 0.1, 0.1, 1.0 },
    tileHover = { 0.25, 0.25, 0.25, 1.0 },
    drop = { 0.2, 0.8, 0.2, 1.0 },
    refuse = { 0.8, 0.2, 0.2, 1.0 },
    job = { 0.4, 1.0, 0.3, 0.2 },
    bright = { 1.0, 1.0, 1.0, 1.0 },
    muted = { 0.7, 0.7, 0.7, 1.0 },
    dim = { 0.5, 0.5, 0.5, 1.0 },
    good = { 0.2, 0.8, 0.2, 1.0 },
    warn = { 1.0, 0.95, 0.45, 1.0 },
    bad = { 0.8, 0.2, 0.2, 1.0 },
    track = { 0.0, 0.0, 0.0, 0.75 },
    scrollBar = { 0.7, 0.7, 0.7, 0.6 },
}
local MODERN = {
    panelEdge = { 1.0, 1.0, 1.0, 0.12 },
    lightEdge = { 1.0, 1.0, 1.0, 0.6 },
    header = { 0.0, 0.0, 0.0, 0.4 },
    headerHover = { 1.0, 1.0, 1.0, 0.08 },
    buttonFill = { 0.0, 0.0, 0.0, 0.4 },
    field = { 0.0, 0.0, 0.0, 0.4 },
    tile = { 0.0, 0.0, 0.0, 0.3 },
    tileHover = { 1.0, 1.0, 1.0, 0.07 },
    drop = { 0.45, 0.72, 0.38, 0.9 },
    refuse = { 0.85, 0.3, 0.25, 0.9 },
    job = { 0.46, 0.7, 0.37, 0.28 },
    bright = { 0.95, 0.95, 0.93, 1.0 },
    muted = { 0.7, 0.7, 0.68, 1.0 },
    dim = { 0.5, 0.5, 0.49, 1.0 },
    good = { 0.46, 0.7, 0.37, 1.0 },
    warn = { 0.9, 0.67, 0.27, 1.0 },
    bad = { 0.84, 0.31, 0.26, 1.0 },
    track = { 1.0, 1.0, 1.0, 0.12 },
    scrollBar = { 0.95, 0.95, 0.93, 0.45 },
}

local LOOKS = { VANILLA, MODERN }




local RIM, HAIRLINE = { 1.0, 1.0, 1.0, 0.08 }, { 1.0, 1.0, 1.0, 0.1 }
local TILE_EDGE, TILE_HOVER_EDGE = { 1.0, 1.0, 1.0, 0.08 }, { 1.0, 1.0, 1.0, 0.6 }

local CONDITION_INNER = 0.5
local BUTTON_EDGE, BUTTON_HOVER_EDGE = { 1.0, 1.0, 1.0, 0.14 }, { 1.0, 1.0, 1.0, 0.45 }
local TAB_FILL, TAB_ON, TAB_OVER = { 0.0, 0.0, 0.0, 0.55 }, 0.08, 0.05
local ACCENT_WASH, RULE = 0.12, 2
local ON_ACCENT = { 0.06, 0.06, 0.06, 1.0 }

local GAME_BOX, BOX_EDGE = { 0.9, 0.9, 1.0, 0.4 }, 0.8


for k, c in pairs(VANILLA) do S[k] = { c[1], c[2], c[3], c[4] } end
S.modern = false
S.backdrop = { 0.0, 0.0, 0.0, 0.18 }
S.panel = { 0.0, 0.0, 0.0, 0.8 }
S.wash = { 1.0, 1.0, 1.0, 0.2 }
S.selected = { 0.92, 0.92, 0.9, 1.0 }
S.accent = { 0.92, 0.92, 0.9, 1.0 }
S.amount = { 0.95, 0.95, 0.95, 0.85 }


local CONDITION_STOPS = { { 0.86, 0.2, 0.16 }, { 0.95, 0.52, 0.16 }, { 0.92, 0.84, 0.25 }, { 0.36, 0.78, 0.34 } }
local CONDITIONS = {}
for i = 0, 100 do
    local at = i / 100 * (#CONDITION_STOPS - 1)
    local k = math.min(math.floor(at), #CONDITION_STOPS - 2)
    local t, a, b = at - k, CONDITION_STOPS[k + 1], CONDITION_STOPS[k + 2]
    CONDITIONS[i] = { a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t, a[3] + (b[3] - a[3]) * t, 1.0 }
end



S.ACCENTS = {
    { 0.88, 0.69, 0.33 }, { 0.98, 0.42, 0.06 }, { 0.84, 0.31, 0.26 }, { 0.46, 0.7, 0.37 }, { 0.36, 0.6, 0.9 },
    { 0.92, 0.92, 0.9 },
}

S.tints = true


local TYPE_COLOURS = {
    false, { 0.86, 0.27, 0.22 }, { 0.95, 0.55, 0.16 }, { 0.92, 0.8, 0.26 }, { 0.38, 0.76, 0.34 },
    { 0.2, 0.7, 0.68 }, { 0.32, 0.56, 0.95 }, { 0.63, 0.42, 0.9 }, { 0.92, 0.46, 0.7 }, { 0.62, 0.62, 0.6 },
    { 0.0, 0.0, 0.0 },
}


S.types = {}



local titleBar = getTexture("media/ui/Panel_TitleBar.png")
local tabOn = getTexture("media/ui/XpSystemUI/tab_selected.png")
local tabOff = getTexture("media/ui/XpSystemUI/tab_unselected.png")







function S.metrics(scale)
    local tm = getTextManager()
    local font = tm:getFontHeight(UIFont.Small)
    local m = { font = font }
    m.pad = math.max(4, math.floor(font * 0.45))
    m.gap = 3
    m.unit = math.floor(math.max(40, math.floor(font * 3.1)) * 0.75)
    m.tile = math.floor(m.unit * (scale or 1))
    m.icon = math.floor(m.tile * 0.64)
    m.header = font + m.pad * 2
    m.bar = math.max(3, math.floor(font * 0.25))
    m.title = S.modern and tm:getFontHeight(UIFont.Medium) + m.pad * 2 or math.max(16, font + m.pad)
    m.inset = S.modern and 1 or 4
    m.track = S.modern and math.max(1, math.floor(font * 0.09)) or 0
    m.titleTrack = S.modern and math.max(1, math.floor(font * 0.14)) or 0
    return m
end



function S.useLook(i)
    S.modern = i == 1
    for k, c in pairs(LOOKS[i + 1] or VANILLA) do
        local t = S[k]
        t[1], t[2], t[3], t[4] = c[1], c[2], c[3], c[4]
    end
end


function S.useAccent(i)
    local c = S.ACCENTS[i + 1] or S.ACCENTS[1]
    for k = 1, 3 do S.accent[k], S.selected[k] = c[k], c[k] end
end


function S.caps(text)
    return S.modern and string.upper(text) or text
end

function S.rect(ui, x, y, w, h, c, a)
    ui.javaObject:DrawTextureScaledColor(nil, x, y, w, h, c[1], c[2], c[3], a or c[4])
end

function S.edge(ui, x, y, w, h, c, a)
    local o, alpha = ui.javaObject, a or c[4]
    o:DrawTextureScaledColor(nil, x, y, w, 1, c[1], c[2], c[3], alpha)
    o:DrawTextureScaledColor(nil, x, y + h - 1, w, 1, c[1], c[2], c[3], alpha)
    o:DrawTextureScaledColor(nil, x, y + 1, 1, h - 2, c[1], c[2], c[3], alpha)
    o:DrawTextureScaledColor(nil, x + w - 1, y + 1, 1, h - 2, c[1], c[2], c[3], alpha)
end


function S.bar(ui, x, y, w, h, fraction, c)
    local f = math.max(0, math.min(1, fraction or 0))
    S.rect(ui, x, y, w, h, S.track)
    if f > 0 then S.rect(ui, x, y, math.max(1, math.floor(w * f)), h, c) end
end

function S.text(ui, str, x, y, c, a, font)
    ui.javaObject:DrawText(font or UIFont.Small, str, x, y, c[1], c[2], c[3], a or c[4])
end

function S.textRight(ui, str, x, y, c, a, font)
    ui.javaObject:DrawTextRight(font or UIFont.Small, str, x, y, c[1], c[2], c[3], a or c[4])
end

function S.textCentre(ui, str, x, y, c, a, font)
    ui.javaObject:DrawTextCentre(font or UIFont.Small, str, x, y, c[1], c[2], c[3], a or c[4])
end






local layouts = {}

local function layout(font, text)
    local tm = getTextManager()
    local height = tm:getFontHeight(font)
    local known = layouts[font]
    if not known or known.height ~= height then
        known = { height = height, texts = {} }
        layouts[font] = known
    end
    local l = known.texts[text]
    if l then return l end
    l = { width = tm:MeasureStringX(font, text) }
    for i = 1, #text do
        l[i] = tm:MeasureStringX(font, string.sub(text, 1, i)) - tm:MeasureStringX(font, string.sub(text, i, i))
    end
    known.texts[text] = l
    return l
end


local function trackedWidth(text, font, track)
    return layout(font, text).width + track * math.max(0, #text - 1)
end


local function tracked(ui, text, x, y, c, font, track)
    local o, l = ui.javaObject, layout(font, text)
    for i = 1, #text do
        o:DrawText(font, string.sub(text, i, i), x + l[i] + track * (i - 1), y, c[1], c[2], c[3], c[4])
    end
end


function S.labelWidth(m, text)
    if S.modern then return trackedWidth(text, UIFont.Small, m.track) end
    return getTextManager():MeasureStringX(UIFont.Small, text)
end


function S.icon(ui, texture, x, y, size, a, r, g, b)
    if texture then ui.javaObject:DrawTextureScaledAspect(texture, x, y, size, size, r or 1, g or 1, b or 1, a or 1) end
end


local function ring(o, x, y, w, h, t, c, shade, a)
    local r, g, b = c[1] * shade, c[2] * shade, c[3] * shade
    o:DrawTextureScaledColor(nil, x, y, w, t, r, g, b, a)
    o:DrawTextureScaledColor(nil, x, y + h - t, w, t, r, g, b, a)
    o:DrawTextureScaledColor(nil, x, y + t, t, h - t * 2, r, g, b, a)
    o:DrawTextureScaledColor(nil, x + w - t, y + t, t, h - t * 2, r, g, b, a)
end





function S.titleBand(ui, m, x, y, w, title, centred)
    if S.modern then
        local text = string.upper(title)
        local width = trackedWidth(text, UIFont.Medium, m.titleTrack)
        local tx = centred and x + math.floor((w - width) / 2) or x + m.pad
        tracked(ui, text, tx, y + m.pad, S.bright, UIFont.Medium, m.titleTrack)
        S.rect(ui, x + 1, y + m.title - 1, w - 2, 1, HAIRLINE)
        S.rect(ui, tx, y + m.title - RULE, width, RULE, S.accent)
        return
    end
    ui.javaObject:DrawTextureScaledColor(titleBar, x + 2, y + 1, w - 4, m.title - 2, 1, 1, 1, 1)
    S.edge(ui, x, y, w, m.title, S.panelEdge)
    S.textCentre(ui, title, x + math.floor(w / 2), y + math.floor((m.title - m.font) / 2), S.bright)
end



function S.box(ui, x, y, w, h)
    S.rect(ui, x, y, w, h, S.panel)
    S.edge(ui, x, y, w, h, S.modern and RIM or S.panelEdge)
end


function S.window(ui, m, x, y, w, h, title, centred)
    S.box(ui, x, y, w, h)
    S.titleBand(ui, m, x, y, w, title, centred)
end




function S.componentHeader(ui, x, y, w, h, over)
    if S.modern then
        S.rect(ui, x, y, w, h, over and S.headerHover or S.header)
        return
    end
    S.rect(ui, x, y, w, h, S.header)
    ui.javaObject:DrawTextureScaledColor(titleBar, x, y, w, h, 1, 1, 1, 1)
    if over then S.rect(ui, x, y, w, h, S.wash, 0.08) end
    S.edge(ui, x, y, w, h, S.panelEdge)
end



local function modernSlot(ui, x, y, w, h, hover, edge, selected, condition)
    S.rect(ui, x, y, w, h, S.tile)
    if selected and not edge then
        S.rect(ui, x, y, w, h, S.selected, ACCENT_WASH)
        S.edge(ui, x, y, w, h, S.selected)
        S.edge(ui, x + 1, y + 1, w - 2, h - 2, S.selected)
        return
    end
    if hover then S.rect(ui, x, y, w, h, S.tileHover) end
    if condition and not edge then
        S.edge(ui, x, y, w, h, condition)
        S.edge(ui, x + 1, y + 1, w - 2, h - 2, condition, CONDITION_INNER)
        return
    end
    S.edge(ui, x, y, w, h, edge or (hover and TILE_HOVER_EDGE or TILE_EDGE))
end






function S.slotBox(ui, x, y, w, h, hover, edge, selected, empty, condition)
    if S.modern then return modernSlot(ui, x, y, w, h, hover, edge, selected, condition) end
    local o = ui.javaObject
    local fill = hover and S.tileHover or S.tile
    o:DrawTextureScaledColor(nil, x, y, w, h, fill[1], fill[2], fill[3], fill[4])
    if selected then o:DrawTextureScaledColor(nil, x, y, w, h, 1, 1, 1, S.wash[4]) end
    local c = edge or (selected and S.selected or condition or S.panelEdge)
    local a = (empty and not edge and not hover) and 0.4 or 1.0
    ring(o, x, y, w, h, 2, c, 1.0, a)
    ring(o, x + 2, y + 2, w - 4, h - 4, 2, c, 0.5 * a, 1.0)
    local r, g, b = c[1] * 0.75 * a, c[2] * 0.75 * a, c[3] * 0.75 * a
    o:DrawTextureScaledColor(nil, x + w - 4, y + 2, 2, h - 4, r, g, b, 1.0)
    o:DrawTextureScaledColor(nil, x + 2, y + h - 4, w - 4, 2, r, g, b, 1.0)
end




function S.button(ui, m, x, y, w, h, label, over, off, strong)
    local tx, ty = x + math.floor(w / 2), y + math.floor((h - m.font) / 2)
    label = S.fit(label, w - m.pad * 2)
    if S.modern and strong then
        if over then
            S.rect(ui, x, y, w, h, S.accent)
            S.textCentre(ui, label, tx, ty, ON_ACCENT)
            return
        end
        S.rect(ui, x, y, w, h, S.buttonFill)
        S.rect(ui, x, y, w, h, S.accent, ACCENT_WASH)
        S.edge(ui, x, y, w, h, S.accent, 0.75)
        S.textCentre(ui, label, tx, ty, S.accent)
        return
    end
    local lit = over and not off
    S.rect(ui, x, y, w, h, lit and S.headerHover or S.buttonFill)
    local rim = S.modern and (lit and BUTTON_HOVER_EDGE or BUTTON_EDGE) or S.lightEdge
    S.edge(ui, x, y, w, h, off and S.panelEdge or rim)
    local colour = off and S.dim or ((S.modern and not lit) and S.muted or S.bright)
    S.textCentre(ui, label, tx, ty, colour)
end





function S.tab(ui, m, x, y, w, h, text, on, over)
    local tx, ty = x + math.floor(w / 2), y + math.floor((h - m.font) / 2)
    if S.modern then
        S.rect(ui, x, y, w, h, TAB_FILL)
        if on or over then S.rect(ui, x, y, w, h, S.wash, on and TAB_ON or TAB_OVER) end
        if on then S.rect(ui, x, y + h - RULE, w, RULE, S.accent) end
        local lx = x + math.floor((w - trackedWidth(text, UIFont.Small, m.track)) / 2)
        tracked(ui, text, lx, ty, (on or over) and S.bright or S.muted, UIFont.Small, m.track)
        return
    end
    local o = ui.javaObject
    o:DrawTextureScaledColor(on and tabOn or tabOff, x, y, w, h, 1, 1, 1, 1)
    if over and not on then o:DrawTextureScaledColor(tabOn, x, y, w, h, 1, 1, 1, 0.2) end
    S.textCentre(ui, text, tx, ty, S.bright)
end



function S.selectionBox(ui, x, y, w, h)
    if S.modern then
        S.rect(ui, x, y, w, h, S.accent, ACCENT_WASH)
        S.edge(ui, x, y, w, h, S.accent, BOX_EDGE)
        return
    end
    S.edge(ui, x, y, w, h, GAME_BOX)
end



function S.focusRing(ui, x, y, w, h)
    S.edge(ui, x - 2, y - 2, w + 4, h + 4, S.accent)
    S.edge(ui, x - 1, y - 1, w + 2, h + 2, S.accent)
end


function S.rowHover(ui, x, y, w, h)
    if S.modern then
        S.rect(ui, x, y, w, h, S.headerHover)
    else
        S.rect(ui, x, y, w, h, S.wash, 0.08)
    end
end




function S.soft(ui, x, y, w, h, r, c, a)
    local o, alpha = ui.javaObject, a or c[4]
    r = math.max(0, math.min(r, math.floor(h / 2), math.floor(w / 2)))
    if h - r * 2 > 0 then o:DrawTextureScaledColor(nil, x, y + r, w, h - r * 2, c[1], c[2], c[3], alpha) end
    for i = 0, r - 1 do
        local dy = r - i - 0.5
        local inset = r - math.floor(math.sqrt(r * r - dy * dy) + 0.5)
        o:DrawTextureScaledColor(nil, x + inset, y + i, w - inset * 2, 1, c[1], c[2], c[3], alpha)
        o:DrawTextureScaledColor(nil, x + inset, y + h - 1 - i, w - inset * 2, 1, c[1], c[2], c[3], alpha)
    end
end



function S.rowSelected(ui, x, y, w, h)
    if S.modern then
        S.soft(ui, x, y, w, h, 4, S.selected, ACCENT_WASH)
    else
        S.rect(ui, x, y, w, h, S.wash)
    end
end


function S.triangle(ui, x, y, size, up, c)
    local rows = math.ceil(size / 2)
    for i = 0, rows - 1 do
        S.rect(ui, x + i, up and y + rows - 1 - i or y + i, size - i * 2, 1, c)
    end
end



function S.segment(ui, x, y, w, h, on, over)
    S.rect(ui, x, y, w, h, on and S.headerHover or S.buttonFill)
    if over and not on then S.rect(ui, x, y, w, h, S.wash, 0.08) end
    S.edge(ui, x, y, w, h, S.modern and BUTTON_EDGE or S.lightEdge)
end


function S.fullness(fraction)
    if fraction > 1.0 then return S.bad end
    if fraction > 0.75 then return S.warn end
    return S.good
end


function S.wholeness(fraction)
    if fraction < 0.25 then return S.bad end
    if fraction < 0.5 then return S.warn end
    return S.good
end




function S.condition(fraction, broken)
    if not S.tints then return nil end
    if broken then return CONDITIONS[0] end
    if not fraction then return nil end
    return CONDITIONS[math.floor(math.max(0, math.min(1, fraction)) * 100 + 0.5)]
end



function S.useTypes(on, strength, colour, count)
    for i = 1, count do
        local c = on and TYPE_COLOURS[colour(i - 1) + 1]
        if c then
            local t = S.types[i] or {}
            t[1], t[2], t[3], t[4] = c[1], c[2], c[3], strength
            S.types[i] = t
        else
            S.types[i] = false
        end
    end
end


function S.typeTint(t)
    return t and S.types[t] or nil
end


function S.weight(value)
    return string.format("%.1f", math.floor((value or 0) * 10 + 0.5) / 10)
end



local fitted, fittedCount = {}, 0

function S.fit(str, width, font)
    font = font or UIFont.Small
    local key = str .. "\0" .. math.floor(width) .. "\0" .. tostring(font)
    if fitted[key] then return fitted[key] end
    local tm = getTextManager()
    local cut = str
    if tm:MeasureStringX(font, str) > width then
        while #cut > 1 and tm:MeasureStringX(font, cut .. "...") > width do
            cut = string.sub(cut, 1, #cut - 1)
        end
        cut = cut .. "..."
    end
    if fittedCount > 400 then fitted, fittedCount = {}, 0 end
    fitted[key], fittedCount = cut, fittedCount + 1
    return cut
end
