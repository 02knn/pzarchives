AUDIO OCCLUSION OVERHAUL — 0.1.6-alpha STUDIO BY-ID ACOUSTIC PATH
Project Zomboid Build 42.21.0 | Viewpoint nightly 0.1.7-rc3 | ZombieBuddy 2.3.4

WHY THIS VERSION CHANGES THE IMPLEMENTATION
The 0.1.5 console confirmed that the mod loaded and that Viewpoint's Studio event placement hook ran. It did not show any SetParameterByName calls or Core Set3DOcclusion writes. Static inspection of Build 42.21's FMODLocalParameter.setCurrentValue shows that the game's local parameters (including ParameterOcclusion) are sent with FMOD_Studio_EventInstance_SetParameterByID. Viewpoint routes that native call through SoundNatives.lambda$events$7. Version 0.1.5 only watched lambda$events$8 (ByName), so it missed the game's actual local-parameter route.

WHAT 0.1.6 DOES
1. Intercepts Viewpoint's Studio SetParameterByID bridge (lambda$events$7) as well as SetParameterByName (lambda$events$8).
2. Resolves the exact FMOD parameter ID for the game's parameter named "Occlusion" and only changes that parameter. Other parameter IDs pass through untouched.
3. Uses the source position previously supplied to Viewpoint by FmodEvents.place and the local player's current world position.
4. Computes transmission through the current map geometry (walls, doors, windows, barricades and floor separation), then replaces the incoming Occlusion value for that event instance.
5. Keeps the existing ParameterOcclusion calculation hook as a fallback for the game's direct local-parameter path.
6. Caches event paths for 100 ms with a bounded 512-event cache. The source position map is also bounded to 512 handles.

SAFE FALLBACKS
The incoming vanilla value is preserved if the parameter ID cannot be resolved, the event position has not been recorded, no local player is available, the source is beyond 60 tiles, required map squares are missing, or the geometry trace fails. The change is client-local; no values are sent over the network. This is an Occlusion-parameter correction, not a global volume slider.

INSTALL
1. Remove the entire previous AudioOcclusionOverhaul folder before installing this one.
2. Keep ZombieBuddy 2.3.4 and Viewpoint nightly 0.1.7-rc3 enabled. This build targets the inspected Viewpoint 0.1.7-rc3 callbacks and Project Zomboid 42.21.0.
3. Do not keep a second copy of AudioOcclusionOverhaul active.

WHAT TO TEST
Load the same save and stay inside the house where the neighbor/NPC bedroom-door sound was previously too loud. Listen for the same sound through the closed interior door, then compare it with the door open. No special diagnostic hunt is needed. The intended result is a clear reduction through the closed door while an open door remains comparatively transmissive.

LIMITATIONS / VERIFICATION
This was statically checked against the supplied Project Zomboid 42.21.0 game JAR and Viewpoint nightly 0.1.7-rc3 bytecode. The Java project compiles and the produced JAR contains only this mod's classes. I cannot launch the user's game environment here, so the actual audible result is not claimed as in-game verified. If the event's source position or FMOD parameter ID is unavailable, the code deliberately leaves the vanilla value unchanged rather than guessing.

Diagonal path handling: when both orthogonal routes exist, the more blocked route is used to prevent sound leaking through a corner; if only one adjacent route exists, that valid route is used.
