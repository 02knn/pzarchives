package audioocclusionoverhaul;

import me.zed_0xff.zombie_buddy.Patch;

/** Viewpoint 0.1.7-rc3 bridge for the game's actual FMOD SetParameterByID path. */
@Patch(className = "viewpoint.sound.SoundNatives", methodName = "lambda$events$7")
public final class Patch_ViewpointStudioParameterById {
    private Patch_ViewpointStudioParameterById() {}

    @Patch.OnEnter
    public static void enter(
            @Patch.Argument(2) long eventInstance,
            @Patch.Argument(3) long parameterIdAddress,
            @Patch.Argument(value = 4, readOnly = false) float value) {
        value = FmodDiagnostics.overrideStudioParameterById(eventInstance, parameterIdAddress, value);
    }
}
