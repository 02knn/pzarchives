package audioocclusionoverhaul;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import org.lwjgl.system.MemoryUtil;

/** One-pass diagnostic taps for the game's and Viewpoint's audio paths. */
public final class FmodDiagnostics {
    private static final AtomicInteger PARAMETER_CALC_HITS = new AtomicInteger();
    private static final AtomicInteger STUDIO_OCCLUSION_WRITES = new AtomicInteger();
    private static final AtomicInteger CORE_OCCLUSION_WRITES = new AtomicInteger();
    private static final AtomicInteger CORE_POSITION_WRITES = new AtomicInteger();
    private static final AtomicInteger STUDIO_POSITION_WRITES = new AtomicInteger();
    private static final int MAX_TRACKED_HANDLES = 512;
    private static final long POSITION_LOG_INTERVAL_NS = 100_000_000L;
    private static final Map<Long, Position> CORE_POSITIONS = boundedMap();
    private static final Map<Long, Position> STUDIO_POSITIONS = boundedMap();
    private static volatile long lastListenerLogNs;
    private static volatile boolean occlusionIdResolved;
    private static volatile long occlusionParameterBits;
    private static final AtomicInteger STUDIO_OCCLUSION_BY_ID_WRITES = new AtomicInteger();
    private static volatile Field playersField;
    private static volatile Method getX, getY, getZ;

    private static final class Position {
        volatile float x, y, z;
        volatile long updatedNs;
        Position(float x, float y, float z, long now) { update(x, y, z, now); }
        void update(float nx, float ny, float nz, long now) { x=nx; y=ny; z=nz; updatedNs=now; }
        String age(long now) { return xyz(x,y,z) + " ageMs=" + ((now-updatedNs)/1_000_000L); }
    }

    private FmodDiagnostics() {}
    private static Map<Long, Position> boundedMap() {
        return new LinkedHashMap<Long, Position>(64, .75f, true) {
            protected boolean removeEldestEntry(Map.Entry<Long, Position> e) { return size() > MAX_TRACKED_HANDLES; }
        };
    }
    private static boolean finite(float x,float y,float z) { return Float.isFinite(x)&&Float.isFinite(y)&&Float.isFinite(z); }
    private static String xyz(float x,float y,float z) { return String.format(Locale.ROOT,"%.2f,%.2f,%.2f",x,y,z); }
    private static void put(Map<Long,Position> map,long id,float x,float y,float z) {
        if(id==0L || !finite(x,y,z)) return;
        long now=System.nanoTime();
        synchronized(map) {
            Position p=map.get(id);
            if(p==null) map.put(id,new Position(x,y,z,now));
            else if(now-p.updatedNs>=POSITION_LOG_INTERVAL_NS) p.update(x,y,z,now);
        }
    }
    private static String lookup(Map<Long,Position> map,long id) {
        synchronized(map) {
            Position p=map.get(id);
            return p==null ? "[position-unseen]" : p.age(System.nanoTime());
        }
    }
    public static void parameterCalculation(int playerIndex) {
        if (playerIndex != 0) return;
        String listenerPosition = listener();
        // Do not waste the limited diagnostic sample quota on menu/startup calls.
        if (listenerPosition.startsWith("[no-local-player]") || listenerPosition.startsWith("[listener-unavailable")) return;
        int n = PARAMETER_CALC_HITS.incrementAndGet();
        if (n <= 12) System.out.println("[AudioOcclusionOverhaul][game] ParameterOcclusion.calculateValueForPlayer player=0 hit="+n+" listener="+listenerPosition);
    }

    public static float overrideStudioParameterByName(long eventInstance, long parameterNameRef, float value) {
        try {
            Object raw = MemoryUtil.memGlobalRefToObject(parameterNameRef);
            if (!(raw instanceof String)) return value;
            String name = (String) raw;
            if (!"Occlusion".equals(name)) return value;
            return applyStudioOcclusion(eventInstance, value, "ByName");
        } catch (Throwable t) {
            logOnce("studio-name", t);
            return value;
        }
    }

    /** The game's FMODLocalParameter calls SetParameterByID, not ByName. */
    public static float overrideStudioParameterById(long eventInstance, long parameterIdAddress, float value) {
        try {
            if (parameterIdAddress == 0L) return value;
            long incomingBits = MemoryUtil.memGetLong(parameterIdAddress);
            long expectedBits = occlusionParameterBits();
            if (expectedBits == 0L || incomingBits != expectedBits) return value;
            return applyStudioOcclusion(eventInstance, value, "ByID");
        } catch (Throwable t) {
            logOnce("studio-id", t);
            return value;
        }
    }

    private static long occlusionParameterBits() throws Exception {
        if (occlusionIdResolved) return occlusionParameterBits;
        synchronized (FmodDiagnostics.class) {
            if (occlusionIdResolved) return occlusionParameterBits;
            Class<?> managerClass = Class.forName("fmod.fmod.FMODManager");
            Object manager = managerClass.getField("instance").get(null);
            if (manager == null) return 0L;
            Object id = managerClass.getMethod("getParameterID", String.class).invoke(manager, "Occlusion");
            if (id == null) return 0L;
            long address = ((Number) id.getClass().getMethod("address").invoke(id)).longValue();
            if (address == 0L) return 0L;
            occlusionParameterBits = MemoryUtil.memGetLong(address);
            occlusionIdResolved = occlusionParameterBits != 0L;
            if (occlusionIdResolved) {
                System.out.println("[AudioOcclusionOverhaul] matched FMOD parameter ID for 'Occlusion'");
            }
            return occlusionParameterBits;
        }
    }

    private static float applyStudioOcclusion(long eventInstance, float originalValue, String route) {
        Position source;
        synchronized (STUDIO_POSITIONS) {
            Position p = STUDIO_POSITIONS.get(eventInstance);
            source = p == null ? null : new Position(p.x, p.y, p.z, p.updatedNs);
        }
        if (source == null) {
            logStudioFallback(eventInstance, originalValue, "position-unseen", route);
            return originalValue;
        }
        float calculated = AcousticPath.calculateForEvent(eventInstance, source.x, source.y, source.z, originalValue);
        if (!Float.isFinite(calculated) || calculated < 0.0f || calculated > 1.0f) {
            logStudioFallback(eventInstance, originalValue, "path-unavailable", route);
            return originalValue;
        }
        int n = STUDIO_OCCLUSION_BY_ID_WRITES.incrementAndGet();
        if (n <= 100) {
            System.out.println("[AudioOcclusionOverhaul][studio-occlusion] route="+route+" event=0x"+Long.toHexString(eventInstance)
                    +" vanilla="+originalValue+" applied="+calculated+" source="+source.age(System.nanoTime())
                    +" listener="+listener()+" write="+n);
        }
        return calculated;
    }

    private static void logStudioFallback(long eventInstance, float originalValue, String reason, String route) {
        int n = STUDIO_OCCLUSION_BY_ID_WRITES.incrementAndGet();
        if (n <= 40) {
            System.out.println("[AudioOcclusionOverhaul][studio-occlusion-fallback] route="+route+" reason="+reason
                    +" vanilla="+originalValue+" event=0x"+Long.toHexString(eventInstance)
                    +" source="+lookup(STUDIO_POSITIONS,eventInstance)+" listener="+listener()+" write="+n);
        }
    }
    public static void studioEventPosition(long event,float x,float y,float z) {
        put(STUDIO_POSITIONS,event,x,y,z);
        int n=STUDIO_POSITION_WRITES.incrementAndGet();
        if(n<=8) System.out.println("[AudioOcclusionOverhaul][studio-position] event=0x"+Long.toHexString(event)+" source="+xyz(x,y,z));
    }
    public static void coreChannelPosition(long channel,float x,float y,float z) {
        put(CORE_POSITIONS,channel,x,y,z);
        int n=CORE_POSITION_WRITES.incrementAndGet();
        if(n<=8) System.out.println("[AudioOcclusionOverhaul][core-position] channel=0x"+Long.toHexString(channel)+" source="+xyz(x,y,z));
    }
    public static void coreChannelOcclusion(long channel,float direct,float reverb) {
        int n=CORE_OCCLUSION_WRITES.incrementAndGet();
        if(n<=120) System.out.println("[AudioOcclusionOverhaul][core-occlusion] direct="+direct+" reverb="+reverb+
            " channel=0x"+Long.toHexString(channel)+" source="+lookup(CORE_POSITIONS,channel)+" listener="+listener()+" write="+n);
    }
    private static String listener() {
        try {
            if(playersField==null) {
                Class<?> c=Class.forName("zombie.characters.IsoPlayer");
                playersField=c.getField("players");
                getX=c.getMethod("getX"); getY=c.getMethod("getY"); getZ=c.getMethod("getZ");
            }
            Object[] players=(Object[])playersField.get(null);
            Object p=players!=null&&players.length>0?players[0]:null;
            if(p==null) return "[no-local-player]";
            return xyz(((Number)getX.invoke(p)).floatValue(),((Number)getY.invoke(p)).floatValue(),((Number)getZ.invoke(p)).floatValue());
        } catch(Throwable t) { return "[listener-unavailable:"+t.getClass().getSimpleName()+"]"; }
    }
    private static volatile boolean errorLogged;
    private static void logOnce(String where,Throwable t) {
        if(!errorLogged) { synchronized(FmodDiagnostics.class) { if(!errorLogged) { errorLogged=true; System.out.println("[AudioOcclusionOverhaul][diagnostic-error] "+where+" "+t); } } }
    }
}
