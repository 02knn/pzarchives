package audioocclusionoverhaul;
public final class Main {
    private Main() {}
    public static void main(String[] args) {
        System.out.println("[AudioOcclusionOverhaul] 0.1.6-alpha Studio ByID acoustic path loaded");
        System.out.println("[AudioOcclusionOverhaul] active paths: game ParameterOcclusion; Viewpoint Studio SetParameterByID/ByName");
        System.out.println("[AudioOcclusionOverhaul] Viewpoint Studio SetParameterByID is matched against FMOD parameter 'Occlusion'");
        System.out.println("[AudioOcclusionOverhaul] event positions are read from FmodEvents.place; acoustic path is client-local");
        System.out.println("[AudioOcclusionOverhaul] vanilla value is preserved when player, source position, or map geometry is unavailable");
    }
}
