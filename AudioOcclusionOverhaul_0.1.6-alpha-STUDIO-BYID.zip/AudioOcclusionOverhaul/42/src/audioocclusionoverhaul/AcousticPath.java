package audioocclusionoverhaul;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.LinkedHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Client-local acoustic path estimator for Project Zomboid Build 42.21.
 *
 * The game's FMOD emitter owns one ParameterOcclusion instance. We patch that
 * parameter's per-player calculation, so every event which declares the
 * existing FMOD "Occlusion" parameter receives a value derived from the
 * listener on this client. No sound value is sent over the network.
 *
 * Geometry queries are deliberately conservative: if any required square or
 * API method is unavailable, NaN is returned and the game's original value is
 * kept. Results are cached per emitter to avoid tracing every audio update.
 */
public final class AcousticPath {
    private static final long CACHE_NS = 100_000_000L; // 100 ms
    private static final double CACHE_MOVE_TILES = 0.55;
    private static final int MAX_PATH_STEPS = 80;
    private static final double MAX_DISTANCE_TILES = 60.0;

    // Transmission coefficients (1 = clear path, 0 = fully blocked).
    // They are intentionally exposed as constants in source for the first test build.
    private static final double TX_OPEN_DOOR = 0.98;
    private static final double TX_CLOSED_DOOR = 0.30;
    private static final double TX_DESTROYED_DOOR = 0.76;
    private static final double TX_OPEN_WINDOW = 0.86;
    private static final double TX_CLOSED_WINDOW = 0.46;
    private static final double TX_BROKEN_WINDOW = 0.91;
    private static final double TX_SOLID_WALL = 0.18;
    private static final double TX_PASSABLE_EDGE = 1.0;
    private static final double TX_PER_FLOOR = 0.48;

    private static final Map<Object, CacheEntry> CACHE = new WeakHashMap<>();
    private static final Map<Long, CacheEntry> EVENT_CACHE = new LinkedHashMap<Long, CacheEntry>(64, .75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<Long, CacheEntry> eldest) {
            return size() > 512;
        }
    };
    private static final AtomicBoolean INIT_LOGGED = new AtomicBoolean();
    private static final AtomicBoolean ERROR_LOGGED = new AtomicBoolean();
    // Only diagnostically relevant world events are logged. The prior generic
    // quota was consumed by global Music/Main at startup, hiding door/window sounds.
    private static final java.util.concurrent.atomic.AtomicInteger DIAG_LINES = new java.util.concurrent.atomic.AtomicInteger();
    private static volatile long lastDiagNs;
    private static final int MAX_DIAG_LINES = 120;

    private static volatile Api api;

    private AcousticPath() {}

    /** Returns NaN to preserve the game's original calculation. */
    public static float calculate(Object parameter, int playerIndex, float originalValue) {
        Object emitter = null;
        float sx = Float.NaN, sy = Float.NaN, sz = Float.NaN;
        float px = Float.NaN, py = Float.NaN, pz = Float.NaN;
        try {
            Api a = api();
            if (playerIndex < 0 || playerIndex >= a.players.length) {
                diagnostic("fallback=invalid-player-index player=" + playerIndex, null, false);
                return Float.NaN;
            }

            emitter = a.emitterField.get(parameter);
            if (emitter == null) {
                diagnostic("fallback=null-emitter player=" + playerIndex, null, false);
                return Float.NaN;
            }

            Object player = a.players[playerIndex];
            if (player == null) return Float.NaN; // Normal for unused local split-screen slots.

            sx = a.emitterX.getFloat(emitter);
            sy = a.emitterY.getFloat(emitter);
            sz = a.emitterZ.getFloat(emitter);
            px = ((Number) a.playerGetX.invoke(player)).floatValue();
            py = ((Number) a.playerGetY.invoke(player)).floatValue();
            pz = ((Number) a.playerGetZ.invoke(player)).floatValue();

            if (!finite(sx, sy, sz, px, py, pz)) {
                diagnostic("fallback=non-finite-position src=" + xyz(sx, sy, sz) + " listener=" + xyz(px, py, pz), emitter, false);
                return Float.NaN;
            }

            double distance = Math.hypot((double) sx - px, (double) sy - py);
            if (distance > MAX_DISTANCE_TILES) {
                diagnostic("fallback=over-range distance=" + fmt(distance) + " src=" + xyz(sx, sy, sz) + " listener=" + xyz(px, py, pz), emitter, false);
                return Float.NaN;
            }

            long now = System.nanoTime();
            CacheEntry previous;
            synchronized (CACHE) {
                previous = CACHE.get(parameter);
                if (previous != null && previous.playerIndex == playerIndex
                        && now - previous.timeNs >= 0 && now - previous.timeNs < CACHE_NS
                        && near(previous.sx, sx) && near(previous.sy, sy) && near(previous.sz, sz)
                        && near(previous.px, px) && near(previous.py, py) && near(previous.pz, pz)) {
                    return previous.occlusion;
                }
            }

            Object world = a.worldInstance.get(null);
            if (world == null) {
                diagnostic("fallback=null-world", emitter, false);
                return Float.NaN;
            }
            Object cell = a.worldGetCell.invoke(world);
            if (cell == null) {
                diagnostic("fallback=null-cell", emitter, false);
                return Float.NaN;
            }

            int sourceX = floor(sx);
            int sourceY = floor(sy);
            int sourceZ = floor(sz);
            Object sourceSquare = a.getGridSquare.invoke(cell, sourceX, sourceY, sourceZ);
            Object targetSquare = a.playerCurrentSquare.invoke(player);
            if (sourceSquare == null || targetSquare == null) {
                diagnostic("fallback=missing-endpoint-square srcTile=" + sourceX + "," + sourceY + "," + sourceZ
                        + " listener=" + xyz(px, py, pz) + " sourceSquare=" + (sourceSquare != null)
                        + " listenerSquare=" + (targetSquare != null), emitter, false);
                return Float.NaN;
            }

            int targetX = ((Number) a.squareGetX.invoke(targetSquare)).intValue();
            int targetY = ((Number) a.squareGetY.invoke(targetSquare)).intValue();
            int actualTargetZ = ((Number) a.squareGetZ.invoke(targetSquare)).intValue();

            double transmission = 1.0;
            int floorDelta = Math.abs(sourceZ - actualTargetZ);
            if (floorDelta > 0) {
                transmission *= Math.pow(TX_PER_FLOOR, Math.min(floorDelta, 3));
            }

            Object traceEnd = a.getGridSquare.invoke(cell, targetX, targetY, sourceZ);
            int traceZ = sourceZ;
            if (traceEnd == null && sourceZ != actualTargetZ) {
                Object alternateStart = a.getGridSquare.invoke(cell, sourceX, sourceY, actualTargetZ);
                Object alternateEnd = a.getGridSquare.invoke(cell, targetX, targetY, actualTargetZ);
                if (alternateStart != null && alternateEnd != null) {
                    traceZ = actualTargetZ;
                    sourceSquare = alternateStart;
                    traceEnd = alternateEnd;
                }
            }

            TraceStats stats = new TraceStats();
            if (traceEnd != null) {
                double horizontal = trace(cell, sx, sy, px, py, traceZ, sourceSquare, traceEnd, a, stats);
                if (!Double.isFinite(horizontal)) {
                    diagnostic("fallback=trace-failed src=" + xyz(sx, sy, sz) + " listener=" + xyz(px, py, pz)
                            + " steps=" + stats.steps, emitter, false);
                    return Float.NaN;
                }
                transmission *= horizontal;
            } else if (floorDelta == 0) {
                diagnostic("fallback=missing-trace-end src=" + xyz(sx, sy, sz) + " listener=" + xyz(px, py, pz), emitter, false);
                return Float.NaN;
            }

            transmission = clamp(transmission, 0.035, 1.0);
            float result = (float) (1.0 - transmission);
            result = clamp(result, 0.0f, 1.0f);

            synchronized (CACHE) {
                CACHE.put(parameter, new CacheEntry(now, playerIndex, sx, sy, sz, px, py, pz, result));
            }

            diagnostic("applied occ=" + fmt(result) + " tx=" + fmt(transmission)
                    + " dist=" + fmt(distance) + " floorDelta=" + floorDelta
                    + " walls=" + stats.walls + " doors=" + stats.doors + " windows=" + stats.windows
                    + " barricades=" + stats.barricades + " openEdges=" + stats.openEdges
                    + " corners=" + stats.corners + " steps=" + stats.steps
                    + " src=" + xyz(sx, sy, sz) + " listener=" + xyz(px, py, pz), emitter, true);
            return result;
        } catch (Throwable t) {
            if (ERROR_LOGGED.compareAndSet(false, true)) {
                System.out.println("[AudioOcclusionOverhaul] Runtime fallback to vanilla occlusion: " + t);
                t.printStackTrace(System.out);
            }
            diagnostic("fallback=exception type=" + t.getClass().getName() + " message=" + String.valueOf(t.getMessage()), emitter, false);
            return Float.NaN;
        }
    }

    /**
     * Viewpoint's Studio bridge receives the game's local Occlusion parameter by ID.
     * This path uses the event-instance position recorded by FmodEvents.place, so it
     * does not depend on the game's FMODSoundEmitter object being available here.
     * NaN means keep the incoming (vanilla) value.
     */
    public static float calculateForEvent(long eventInstance, float sx, float sy, float sz, float originalValue) {
        try {
            Api a = api();
            if (a.players.length == 0 || a.players[0] == null) return Float.NaN;
            Object player = a.players[0];
            float px = ((Number) a.playerGetX.invoke(player)).floatValue();
            float py = ((Number) a.playerGetY.invoke(player)).floatValue();
            float pz = ((Number) a.playerGetZ.invoke(player)).floatValue();
            if (!finite(sx, sy, sz, px, py, pz)) return Float.NaN;

            double distance = Math.hypot((double) sx - px, (double) sy - py);
            if (distance > MAX_DISTANCE_TILES) return Float.NaN;

            long now = System.nanoTime();
            synchronized (EVENT_CACHE) {
                CacheEntry previous = EVENT_CACHE.get(eventInstance);
                if (previous != null && previous.playerIndex == 0
                        && now - previous.timeNs >= 0 && now - previous.timeNs < CACHE_NS
                        && near(previous.sx, sx) && near(previous.sy, sy) && near(previous.sz, sz)
                        && near(previous.px, px) && near(previous.py, py) && near(previous.pz, pz)) {
                    return previous.occlusion;
                }
            }

            Object world = a.worldInstance.get(null);
            if (world == null) return Float.NaN;
            Object cell = a.worldGetCell.invoke(world);
            if (cell == null) return Float.NaN;

            int sourceX = floor(sx), sourceY = floor(sy), sourceZ = floor(sz);
            Object sourceSquare = a.getGridSquare.invoke(cell, sourceX, sourceY, sourceZ);
            Object targetSquare = a.playerCurrentSquare.invoke(player);
            if (sourceSquare == null || targetSquare == null) return Float.NaN;

            int targetX = ((Number) a.squareGetX.invoke(targetSquare)).intValue();
            int targetY = ((Number) a.squareGetY.invoke(targetSquare)).intValue();
            int actualTargetZ = ((Number) a.squareGetZ.invoke(targetSquare)).intValue();
            int floorDelta = Math.abs(sourceZ - actualTargetZ);
            double transmission = floorDelta > 0
                    ? Math.pow(TX_PER_FLOOR, Math.min(floorDelta, 3)) : 1.0;

            Object traceEnd = a.getGridSquare.invoke(cell, targetX, targetY, sourceZ);
            int traceZ = sourceZ;
            if (traceEnd == null && sourceZ != actualTargetZ) {
                Object alternateStart = a.getGridSquare.invoke(cell, sourceX, sourceY, actualTargetZ);
                Object alternateEnd = a.getGridSquare.invoke(cell, targetX, targetY, actualTargetZ);
                if (alternateStart != null && alternateEnd != null) {
                    traceZ = actualTargetZ;
                    sourceSquare = alternateStart;
                    traceEnd = alternateEnd;
                }
            }

            TraceStats stats = new TraceStats();
            if (traceEnd != null) {
                double horizontal = trace(cell, sx, sy, px, py, traceZ, sourceSquare, traceEnd, a, stats);
                if (!Double.isFinite(horizontal)) return Float.NaN;
                transmission *= horizontal;
            } else if (floorDelta == 0) {
                return Float.NaN;
            }

            transmission = clamp(transmission, 0.035, 1.0);
            float result = clamp((float) (1.0 - transmission), 0.0f, 1.0f);
            synchronized (EVENT_CACHE) {
                EVENT_CACHE.put(eventInstance, new CacheEntry(now, 0, sx, sy, sz, px, py, pz, result));
            }
            return result;
        } catch (Throwable t) {
            if (ERROR_LOGGED.compareAndSet(false, true)) {
                System.out.println("[AudioOcclusionOverhaul] Studio acoustic path fallback to incoming value: " + t);
                t.printStackTrace(System.out);
            }
            return Float.NaN;
        }
    }

    private static void diagnostic(String message, Object emitter, boolean applied) {
        try {
            String events = emitter == null ? "[]" : api().activeEvents(emitter);
            if (!isRelevantWorldEvent(events)) return;
            long now = System.nanoTime();
            synchronized (AcousticPath.class) {
                if (DIAG_LINES.get() >= MAX_DIAG_LINES) return;
                if (lastDiagNs != 0 && now - lastDiagNs < 120_000_000L) return;
                lastDiagNs = now;
                DIAG_LINES.incrementAndGet();
            }
            System.out.println("[AudioOcclusionOverhaul][diag] " + (applied ? "APPLIED " : "FALLBACK ")
                    + message + " events=" + events);
        } catch (Throwable ignored) {
            // Diagnostics must never affect audio.
        }
    }

    private static boolean isRelevantWorldEvent(String events) {
        if (events == null || events.isEmpty() || "[]".equals(events) || events.contains("[unavailable]")) return false;
        // Ignore global music/UI events. Prioritize actual spatial world sounds.
        return events.contains("/Object/Door/")
                || events.contains("/Object/WoodDoor/")
                || events.contains("/Object/MetalDoor/")
                || events.contains("/Object/SlidingGlassDoor/")
                || events.contains("/Object/GarageDoor/")
                || events.contains("/Object/Window/")
                || events.contains("/World/Ambient/Door")
                || events.contains("/World/Ambient/Window")
                || events.contains("/Zombie/Thump/")
                || events.contains("/Zombie/Voice/")
                || events.contains("/Weapon/Firearm/")
                || events.contains("/Vehicle/")
                || events.contains("/Character/Voice/");
    }

    private static String xyz(float x, float y, float z) {
        return fmt(x) + "," + fmt(y) + "," + fmt(z);
    }

    private static String fmt(double v) {
        return String.format(java.util.Locale.ROOT, "%.2f", v);
    }

    private static double trace(Object cell, double sx, double sy, double ex, double ey,
                                int z, Object startSquare, Object endSquare, Api a, TraceStats stats) throws Exception {
        int x = floor(sx);
        int y = floor(sy);
        int endX = ((Number) a.squareGetX.invoke(endSquare)).intValue();
        int endY = ((Number) a.squareGetY.invoke(endSquare)).intValue();
        if (x == endX && y == endY) return 1.0;

        double dx = ex - sx;
        double dy = ey - sy;
        int stepX = dx > 0 ? 1 : dx < 0 ? -1 : 0;
        int stepY = dy > 0 ? 1 : dy < 0 ? -1 : 0;
        double tDeltaX = stepX == 0 ? Double.POSITIVE_INFINITY : Math.abs(1.0 / dx);
        double tDeltaY = stepY == 0 ? Double.POSITIVE_INFINITY : Math.abs(1.0 / dy);
        double tMaxX = stepX > 0 ? ((x + 1.0) - sx) / dx : stepX < 0 ? (sx - x) / -dx : Double.POSITIVE_INFINITY;
        double tMaxY = stepY > 0 ? ((y + 1.0) - sy) / dy : stepY < 0 ? (sy - y) / -dy : Double.POSITIVE_INFINITY;

        Object current = startSquare;
        double transmission = 1.0;
        int steps = 0;

        while (x != endX || y != endY) {
            if (++steps > MAX_PATH_STEPS) return Double.NaN;
            stats.steps = steps;

            if (tMaxX + 1e-9 < tMaxY) {
                int nextX = x + stepX;
                Object next = a.getGridSquare.invoke(cell, nextX, y, z);
                if (next == null) return Double.NaN;
                transmission *= edgeTransmission(current, next, stepX, 0, a, stats);
                current = next;
                x = nextX;
                tMaxX += tDeltaX;
            } else if (tMaxY + 1e-9 < tMaxX) {
                int nextY = y + stepY;
                Object next = a.getGridSquare.invoke(cell, x, nextY, z);
                if (next == null) return Double.NaN;
                transmission *= edgeTransmission(current, next, 0, stepY, a, stats);
                current = next;
                y = nextY;
                tMaxY += tDeltaY;
            } else {
                // The ray crosses a tile corner. Evaluate both orthogonal
                // routes conservatively: when both adjacent squares exist,
                // the more blocked side must not be bypassed by the open side.
                // If only one adjacent square exists, use that sole valid route.
                stats.corners++;
                int nextX = x + stepX;
                int nextY = y + stepY;
                Object viaX = a.getGridSquare.invoke(cell, nextX, y, z);
                Object viaY = a.getGridSquare.invoke(cell, x, nextY, z);
                Object diagonal = a.getGridSquare.invoke(cell, nextX, nextY, z);
                if (diagonal == null || (viaX == null && viaY == null)) return Double.NaN;

                double routeX = 0.0;
                if (viaX != null) {
                    routeX = edgeTransmission(current, viaX, stepX, 0, a, stats)
                            * edgeTransmission(viaX, diagonal, 0, stepY, a, stats);
                }
                double routeY = 0.0;
                if (viaY != null) {
                    routeY = edgeTransmission(current, viaY, 0, stepY, a, stats)
                            * edgeTransmission(viaY, diagonal, stepX, 0, a, stats);
                }
                double cornerTransmission;
                if (viaX != null && viaY != null) {
                    cornerTransmission = Math.min(routeX, routeY);
                } else {
                    cornerTransmission = viaX != null ? routeX : routeY;
                }
                transmission *= cornerTransmission;
                current = diagonal;
                x = nextX;
                y = nextY;
                tMaxX += tDeltaX;
                tMaxY += tDeltaY;
            }

            if (transmission < 0.02) break;
        }
        return clamp(transmission, 0.0, 1.0);
    }

    /** Returns sound transmission across one cardinal tile edge. */
    private static double edgeTransmission(Object from, Object to, int dx, int dy, Api a, TraceStats stats) throws Exception {
        Object door = a.squareGetDoorTo.invoke(from, to);
        if (door == null) door = a.squareGetDoorTo.invoke(to, from);
        if (door != null) {
            stats.doors++;
            boolean thumpable = a.thumpableClass.isInstance(door);
            boolean open = boolCall(door, thumpable ? a.thumpableIsOpen : a.doorIsOpen);
            boolean destroyed = optionalBool(door, thumpable ? a.thumpableIsDestroyed : a.doorIsDestroyed);
            double tx = destroyed ? TX_DESTROYED_DOOR : open ? TX_OPEN_DOOR : TX_CLOSED_DOOR;
            Object same = optionalCall(door, thumpable ? a.thumpableBarricadeSame : a.doorBarricadeSame);
            Object opposite = optionalCall(door, thumpable ? a.thumpableBarricadeOpposite : a.doorBarricadeOpposite);
            tx *= barricadeTransmission(same, a, stats);
            tx *= barricadeTransmission(opposite, a, stats);
            return clamp(tx, 0.025, 1.0);
        }

        Object window = a.squareGetWindowTo.invoke(from, to);
        if (window == null) window = a.squareGetWindowTo.invoke(to, from);
        if (window != null) { stats.windows++; return windowTransmission(window, false, a, stats); }

        Object thumpableWindow = a.squareGetWindowThumpableTo.invoke(from, to);
        if (thumpableWindow == null) thumpableWindow = a.squareGetWindowThumpableTo.invoke(to, from);
        if (thumpableWindow != null) { stats.windows++; return windowTransmission(thumpableWindow, true, a, stats); }

        boolean passes;
        if (dx != 0) {
            // The west wall edge belongs to the square on the west side.
            Object edgeSquare = dx > 0 ? to : from;
            passes = (Boolean) a.passesSoundWest.invoke(null, edgeSquare, false);
        } else {
            // The north wall edge belongs to the square on the north side.
            Object edgeSquare = dy > 0 ? to : from;
            passes = (Boolean) a.passesSoundNorth.invoke(null, edgeSquare, false);
        }
        if (passes) stats.openEdges++;
        else stats.walls++;
        return passes ? TX_PASSABLE_EDGE : TX_SOLID_WALL;
    }

    private static double windowTransmission(Object window, boolean thumpable, Api a, TraceStats stats) throws Exception {
        boolean open = boolCall(window, thumpable ? a.thumpableIsOpen : a.windowIsOpen);
        boolean destroyed = optionalBool(window, thumpable ? a.thumpableIsDestroyed : a.windowIsDestroyed);
        double tx = destroyed ? TX_BROKEN_WINDOW : open ? TX_OPEN_WINDOW : TX_CLOSED_WINDOW;

        Object same = optionalCall(window, thumpable ? a.thumpableBarricadeSame : a.windowBarricadeSame);
        Object opposite = optionalCall(window, thumpable ? a.thumpableBarricadeOpposite : a.windowBarricadeOpposite);
        tx *= barricadeTransmission(same, a, stats);
        tx *= barricadeTransmission(opposite, a, stats);
        return clamp(tx, 0.025, 1.0);
    }

    private static double barricadeTransmission(Object barricade, Api a, TraceStats stats) throws Exception {
        if (barricade == null) return 1.0;
        stats.barricades++;
        if (optionalBool(barricade, a.barricadeIsMetal)) return 0.12;
        int planks = optionalInt(barricade, a.barricadePlanks);
        if (planks <= 0) return 0.92;
        return Math.pow(0.82, Math.min(planks, 8));
    }

    private static boolean boolCall(Object target, Method method) throws Exception {
        return (Boolean) method.invoke(target);
    }

    private static boolean optionalBool(Object target, Method method) {
        if (target == null || method == null) return false;
        try { return (Boolean) method.invoke(target); }
        catch (Throwable ignored) { return false; }
    }

    private static int optionalInt(Object target, Method method) {
        if (target == null || method == null) return 0;
        try { return ((Number) method.invoke(target)).intValue(); }
        catch (Throwable ignored) { return 0; }
    }

    private static Object optionalCall(Object target, Method method) {
        if (target == null || method == null) return null;
        try { return method.invoke(target); }
        catch (Throwable ignored) { return null; }
    }

    private static Api api() throws Exception {
        Api current = api;
        if (current != null) return current;
        synchronized (AcousticPath.class) {
            current = api;
            if (current == null) {
                current = new Api();
                api = current;
                if (INIT_LOGGED.compareAndSet(false, true)) {
                    System.out.println("[AudioOcclusionOverhaul] Build 42.21 acoustic path patch initialized (client-local)");
                }
            }
        }
        return current;
    }

    private static final class Api {
        final Field emitterField;
        final Field emitterInstances;
        final Field emitterToStart;
        final Field soundClip;
        final Field clipEvent;
        final Field emitterX;
        final Field emitterY;
        final Field emitterZ;
        final Field worldInstance;
        final Object[] players;

        final Method playerGetX;
        final Method playerGetY;
        final Method playerGetZ;
        final Method playerCurrentSquare;
        final Method worldGetCell;
        final Method getGridSquare;
        final Method squareGetX;
        final Method squareGetY;
        final Method squareGetZ;
        final Method squareGetDoorTo;
        final Method squareGetWindowTo;
        final Method squareGetWindowThumpableTo;
        final Method passesSoundNorth;
        final Method passesSoundWest;
        final Class<?> thumpableClass;
        final Method doorIsOpen;
        final Method doorIsDestroyed;
        final Method thumpableIsOpen;
        final Method thumpableIsDestroyed;
        final Method windowIsOpen;
        final Method windowIsDestroyed;
        final Method windowBarricadeSame;
        final Method windowBarricadeOpposite;
        final Method doorBarricadeSame;
        final Method doorBarricadeOpposite;
        final Method thumpableBarricadeSame;
        final Method thumpableBarricadeOpposite;
        final Method barricadeIsMetal;
        final Method barricadePlanks;

        Api() throws Exception {
            Class<?> parameterClass = Class.forName("zombie.audio.parameters.ParameterOcclusion");
            Class<?> emitterClass = Class.forName("fmod.fmod.FMODSoundEmitter");
            Class<?> playerClass = Class.forName("zombie.characters.IsoPlayer");
            Class<?> worldClass = Class.forName("zombie.iso.IsoWorld");
            Class<?> cellClass = Class.forName("zombie.iso.IsoCell");
            Class<?> squareClass = Class.forName("zombie.iso.IsoGridSquare");
            Class<?> ambientWallClass = Class.forName("zombie.audio.FMODAmbientWallLevelData");
            Class<?> doorClass = Class.forName("zombie.iso.objects.IsoDoor");
            Class<?> windowClass = Class.forName("zombie.iso.objects.IsoWindow");
            thumpableClass = Class.forName("zombie.iso.objects.IsoThumpable");
            Class<?> barricadeClass = Class.forName("zombie.iso.objects.IsoBarricade");

            emitterField = field(parameterClass, "emitter");
            emitterInstances = field(emitterClass, "instances");
            emitterToStart = field(emitterClass, "toStart");
            Class<?> soundClass = Class.forName("fmod.fmod.FMODSoundEmitter$Sound");
            Class<?> clipClass = Class.forName("zombie.audio.GameSoundClip");
            soundClip = field(soundClass, "clip");
            clipEvent = field(clipClass, "event");
            emitterX = field(emitterClass, "x");
            emitterY = field(emitterClass, "y");
            emitterZ = field(emitterClass, "z");
            worldInstance = field(worldClass, "instance");
            players = (Object[]) playerClass.getField("players").get(null);

            playerGetX = playerClass.getMethod("getX");
            playerGetY = playerClass.getMethod("getY");
            playerGetZ = playerClass.getMethod("getZ");
            playerCurrentSquare = playerClass.getMethod("getCurrentSquare");
            worldGetCell = worldClass.getMethod("getCell");
            getGridSquare = cellClass.getMethod("getGridSquare", int.class, int.class, int.class);
            squareGetX = squareClass.getMethod("getX");
            squareGetY = squareClass.getMethod("getY");
            squareGetZ = squareClass.getMethod("getZ");
            squareGetDoorTo = squareClass.getMethod("getDoorTo", squareClass);
            squareGetWindowTo = squareClass.getMethod("getWindowTo", squareClass);
            squareGetWindowThumpableTo = squareClass.getMethod("getWindowThumpableTo", squareClass);
            passesSoundNorth = ambientWallClass.getMethod("passesSoundNorth", squareClass, boolean.class);
            passesSoundWest = ambientWallClass.getMethod("passesSoundWest", squareClass, boolean.class);
            doorIsOpen = doorClass.getMethod("IsOpen");
            doorIsDestroyed = doorClass.getMethod("isDestroyed");
            thumpableIsOpen = thumpableClass.getMethod("IsOpen");
            thumpableIsDestroyed = thumpableClass.getMethod("isDestroyed");
            windowIsOpen = windowClass.getMethod("IsOpen");
            windowIsDestroyed = windowClass.getMethod("isDestroyed");
            windowBarricadeSame = windowClass.getMethod("getBarricadeOnSameSquare");
            windowBarricadeOpposite = windowClass.getMethod("getBarricadeOnOppositeSquare");
            doorBarricadeSame = doorClass.getMethod("getBarricadeOnSameSquare");
            doorBarricadeOpposite = doorClass.getMethod("getBarricadeOnOppositeSquare");
            thumpableBarricadeSame = thumpableClass.getMethod("getBarricadeOnSameSquare");
            thumpableBarricadeOpposite = thumpableClass.getMethod("getBarricadeOnOppositeSquare");
            barricadeIsMetal = barricadeClass.getMethod("isMetal");
            barricadePlanks = barricadeClass.getMethod("getNumPlanks");
        }

        String activeEvents(Object emitter) {
            try {
                java.util.LinkedHashSet<String> names = new java.util.LinkedHashSet<>();
                appendEvents(names, emitterInstances.get(emitter));
                appendEvents(names, emitterToStart.get(emitter));
                return names.isEmpty() ? "[]" : names.toString();
            } catch (Throwable ignored) {
                return "[unavailable]";
            }
        }

        private void appendEvents(java.util.Set<String> names, Object collection) throws Exception {
            if (!(collection instanceof java.util.List<?> list)) return;
            for (Object sound : list) {
                Object clip = soundClip.get(sound);
                if (clip == null) continue;
                Object event = clipEvent.get(clip);
                if (event != null) names.add(String.valueOf(event));
                if (names.size() >= 12) return;
            }
        }

        private static Field field(Class<?> owner, String name) throws Exception {
            Field f = owner.getDeclaredField(name);
            f.setAccessible(true);
            return f;
        }
    }

    private static final class TraceStats {
        int steps;
        int walls;
        int doors;
        int windows;
        int barricades;
        int openEdges;
        int corners;
    }

    private static final class CacheEntry {
        final long timeNs;
        final int playerIndex;
        final float sx, sy, sz, px, py, pz;
        final float occlusion;

        CacheEntry(long timeNs, int playerIndex, float sx, float sy, float sz,
                   float px, float py, float pz, float occlusion) {
            this.timeNs = timeNs;
            this.playerIndex = playerIndex;
            this.sx = sx; this.sy = sy; this.sz = sz;
            this.px = px; this.py = py; this.pz = pz;
            this.occlusion = occlusion;
        }
    }

    private static boolean near(float a, float b) {
        return Math.abs(a - b) <= CACHE_MOVE_TILES;
    }

    private static int floor(double value) {
        return (int) Math.floor(value);
    }

    private static boolean finite(float... values) {
        for (float v : values) if (!Float.isFinite(v)) return false;
        return true;
    }

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
