package audioocclusionoverhaul;

import me.zed_0xff.zombie_buddy.Patch;

/** Observes Viewpoint's FMOD_Channel_Set3DOcclusion bridge without changing it. */
@Patch(className = "viewpoint.sound.FmodCore", methodName = "setOcclusion")
public final class Patch_ViewpointCoreOcclusion {
    private Patch_ViewpointCoreOcclusion() {}

    @Patch.OnEnter
    public static void enter(
            @Patch.Argument(0) long channel,
            @Patch.Argument(1) float direct,
            @Patch.Argument(2) float reverb) {
        FmodDiagnostics.coreChannelOcclusion(channel, direct, reverb);
    }
}
