package audioocclusionoverhaul;

import me.zed_0xff.zombie_buddy.Patch;

/** Records Viewpoint Core FMOD channel placement without changing it. */
@Patch(className = "viewpoint.sound.FmodCore", methodName = "place")
public final class Patch_ViewpointCorePosition {
    private Patch_ViewpointCorePosition() {}

    @Patch.OnEnter
    public static void enter(
            @Patch.Argument(0) long channel,
            @Patch.Argument(1) float x,
            @Patch.Argument(2) float y,
            @Patch.Argument(3) float z) {
        FmodDiagnostics.coreChannelPosition(channel, x, y, z);
    }
}
