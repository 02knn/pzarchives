package audioocclusionoverhaul;

import me.zed_0xff.zombie_buddy.Patch;

/** Viewpoint 0.1.7-rc3 bridge for FMOD_Studio_EventInstance_SetParameterByName. */
@Patch(className = "viewpoint.sound.SoundNatives", methodName = "lambda$events$8")
public final class Patch_ViewpointStudioParameter {
    private Patch_ViewpointStudioParameter() {}

    @Patch.OnEnter
    public static void enter(
            @Patch.Argument(2) long eventInstance,
            @Patch.Argument(3) long parameterNameRef,
            @Patch.Argument(value = 4, readOnly = false) float value) {
        value = FmodDiagnostics.overrideStudioParameterByName(eventInstance, parameterNameRef, value);
    }
}
