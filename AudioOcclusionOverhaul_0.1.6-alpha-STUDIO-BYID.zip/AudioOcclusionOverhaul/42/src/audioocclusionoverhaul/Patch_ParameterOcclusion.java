package audioocclusionoverhaul;

import me.zed_0xff.zombie_buddy.Patch;

/**
 * Replaces the game's binary visibility-based occlusion result with a local
 * source-to-listener acoustic path estimate. The original result is retained
 * whenever the path cannot be evaluated safely.
 */
@Patch(className = "zombie.audio.parameters.ParameterOcclusion", methodName = "calculateValueForPlayer")
public final class Patch_ParameterOcclusion {
    private Patch_ParameterOcclusion() {}

    @Patch.OnEnter
    public static void enter(@Patch.Argument(0) int playerIndex) {
        FmodDiagnostics.parameterCalculation(playerIndex);
    }

    @Patch.OnExit
    public static void exit(
            @Patch.This Object parameter,
            @Patch.Argument(0) int playerIndex,
            @Patch.Return(readOnly = false) float originalValue) {
        float calculated = AcousticPath.calculate(parameter, playerIndex, originalValue);
        if (Float.isFinite(calculated) && calculated >= 0.0f && calculated <= 1.0f) {
            originalValue = calculated;
        }
    }
}
