package audioocclusionoverhaul;

import me.zed_0xff.zombie_buddy.Patch;

/** Records the position of a Viewpoint FMOD Studio event instance. */
@Patch(className = "viewpoint.sound.FmodEvents", methodName = "place")
public final class Patch_ViewpointStudioPosition {
    private Patch_ViewpointStudioPosition() {}

    @Patch.OnEnter
    public static void enter(
            @Patch.Argument(0) long eventInstance,
            @Patch.Argument(1) float x,
            @Patch.Argument(2) float y,
            @Patch.Argument(3) float z) {
        FmodDiagnostics.studioEventPosition(eventInstance, x, y, z);
    }
}
